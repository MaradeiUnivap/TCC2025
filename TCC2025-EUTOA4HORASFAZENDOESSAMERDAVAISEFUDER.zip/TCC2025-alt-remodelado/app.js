const express = require('express');
const path = require('path');
const session = require('express-session');

const app = express();
const porta = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(session({
    secret: 'seuSegredoAqui',
    resave: false,
    saveUninitialized: true
}));


app.use(require('./backend/routes/login'));
app.use(require('./backend/routes/atividades'));
//app.use(require('./backend/routes/grupos'));
app.use(require('./backend/routes/entregas'));
app.use(require('./backend/routes/cadastros'));
app.use(require('./backend/routes/api'));


app.listen(porta, () => {
    console.log('http://localhost:3000/')
});