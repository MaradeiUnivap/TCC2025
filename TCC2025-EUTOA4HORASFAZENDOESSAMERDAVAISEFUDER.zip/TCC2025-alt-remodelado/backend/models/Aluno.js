const banco = require('../../config/database');

class Aluno {
    constructor(idAluno, nomeAluno, turma, emailAluno, senhaAluno, idCurso) {
        this.idAluno = idAluno;
        this.nomeAluno = nomeAluno;
        this.turma = turma;
        this.emailAluno = emailAluno;
        this.senhaAluno = senhaAluno;
        this.idCurso = idCurso;
    }

    // Criar um novo aluno
    static async create(nomeAluno, turma, emailAluno, senhaAluno, idCurso) {
        try {
            const [result] = await banco.execute(
                'INSERT INTO aluno (nomeAluno, turma, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?, ?)',
                [nomeAluno, turma, emailAluno, senhaAluno, idCurso]
            );
            return { 
                idAluno: result.insertId, 
                nomeAluno, 
                turma, 
                emailAluno, 
                senhaAluno, 
                idCurso 
            };
        } catch (error) {
            throw error;
        }
    }

    // Listar todos os alunos
    static async readAll() {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso'
            );
            return rows.map(row => ({
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar aluno por ID
    static async readByID(idAluno) {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso WHERE a.idAluno = ?',
                [idAluno]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            };
        } catch (error) {
            throw error;
        }
    }

    // Buscar aluno por email
    static async byEmail(emailAluno) {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso WHERE a.emailAluno = ?',
                [emailAluno]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            };
        } catch (error) {
            throw error;
        }
    }

    // Login do aluno
    static async login(emailAluno, senhaAluno) {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso WHERE a.emailAluno = ? AND a.senhaAluno = ?',
                [emailAluno, senhaAluno]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            };
        } catch (error) {
            throw error;
        }
    }

    // Atualizar aluno
    static async update(idAluno, nomeAluno, turma, emailAluno, senhaAluno, idCurso) {
        try {
            const [result] = await banco.execute(
                'UPDATE aluno SET nomeAluno = ?, turma = ?, emailAluno = ?, senhaAluno = ?, idCurso = ? WHERE idAluno = ?',
                [nomeAluno, turma, emailAluno, senhaAluno, idCurso, idAluno]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar aluno
    static async delete(idAluno) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM aluno WHERE idAluno = ?',
                [idAluno]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar alunos por curso
    static async getByCurso(idCurso) {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso WHERE a.idCurso = ?',
                [idCurso]
            );
            return rows.map(row => ({
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar alunos por turma
    static async getByTurma(turma) {
        try {
            const [rows] = await banco.execute(
                'SELECT a.*, c.nomeCurso FROM aluno a LEFT JOIN curso c ON a.idCurso = c.idCurso WHERE a.turma = ?',
                [turma]
            );
            return rows.map(row => ({
                ...new Aluno(
                    row.idAluno, 
                    row.nomeAluno, 
                    row.turma, 
                    row.emailAluno, 
                    row.senhaAluno, 
                    row.idCurso
                ),
                nomeCurso: row.nomeCurso
            }));
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Aluno;