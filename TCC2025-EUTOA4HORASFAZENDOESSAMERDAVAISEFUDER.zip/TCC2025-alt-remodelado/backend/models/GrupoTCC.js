const banco = require('../../config/database');

class GrupoTCC {
    constructor(idGrupo, tema, idCurso, idProfessor, status) {
        this.idGrupo = idGrupo;
        this.tema = tema;
        this.idCurso = idCurso;
        this.idProfessor = idProfessor;
        this.status = status;
    }

    // Criar um novo grupo TCC
    static async create(tema, idCurso, idProfessor, status = 'pendente') {
        try {
            const [result] = await banco.execute(
                'INSERT INTO grupotcc (tema, idCurso, idProfessor, status) VALUES (?, ?, ?, ?)',
                [tema, idCurso, idProfessor, status]
            );
            return { 
                idGrupo: result.insertId, 
                tema, 
                idCurso, 
                idProfessor, 
                status 
            };
        } catch (error) {
            throw error;
        }
    }

    // Listar todos os grupos TCC
    static async readAll() {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor 
                FROM grupotcc g 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor
            `);
            return rows.map(row => ({
                ...new GrupoTCC(
                    row.idGrupo, 
                    row.tema, 
                    row.idCurso, 
                    row.idProfessor, 
                    row.status
                ),
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar grupo TCC por ID
    static async readByID(idGrupo) {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor 
                FROM grupotcc g 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.idGrupo = ?
            `, [idGrupo]);
            
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new GrupoTCC(
                    row.idGrupo, 
                    row.tema, 
                    row.idCurso, 
                    row.idProfessor, 
                    row.status
                ),
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            };
        } catch (error) {
            throw error;
        }
    }

    // Atualizar grupo TCC
    static async update(idGrupo, tema, idCurso, idProfessor, status) {
        try {
            const [result] = await banco.execute(
                'UPDATE grupotcc SET tema = ?, idCurso = ?, idProfessor = ?, status = ? WHERE idGrupo = ?',
                [tema, idCurso, idProfessor, status, idGrupo]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar grupo TCC
    static async delete(idGrupo) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM grupotcc WHERE idGrupo = ?',
                [idGrupo]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar grupos por professor
    static async getByProfessor(idProfessor) {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor 
                FROM grupotcc g 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.idProfessor = ?
            `, [idProfessor]);
            
            return rows.map(row => ({
                ...new GrupoTCC(
                    row.idGrupo, 
                    row.tema, 
                    row.idCurso, 
                    row.idProfessor, 
                    row.status
                ),
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar grupos por curso
    static async getByCurso(idCurso) {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor 
                FROM grupotcc g 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.idCurso = ?
            `, [idCurso]);
            
            return rows.map(row => ({
                ...new GrupoTCC(
                    row.idGrupo, 
                    row.tema, 
                    row.idCurso, 
                    row.idProfessor, 
                    row.status
                ),
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar grupos por status
    static async getByStatus(status) {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor 
                FROM grupotcc g 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.status = ?
            `, [status]);
            
            return rows.map(row => ({
                ...new GrupoTCC(
                    row.idGrupo, 
                    row.tema, 
                    row.idCurso, 
                    row.idProfessor, 
                    row.status
                ),
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Atualizar apenas o status do grupo
    static async updateStatus(idGrupo, status) {
        try {
            const [result] = await banco.execute(
                'UPDATE grupotcc SET status = ? WHERE idGrupo = ?',
                [status, idGrupo]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = GrupoTCC;