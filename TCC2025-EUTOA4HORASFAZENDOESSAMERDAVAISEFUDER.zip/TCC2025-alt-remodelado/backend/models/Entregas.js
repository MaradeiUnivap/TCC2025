const banco = require('../../config/database');

class Entregas {
    constructor(idEntrega, nome_original, nome_servidor, caminho_arquivo, data_envio, atividade_idatividade, grupotcc_idGrupo) {
        this.idEntrega = idEntrega;
        this.nome_original = nome_original;
        this.nome_servidor = nome_servidor;
        this.caminho_arquivo = caminho_arquivo;
        this.data_envio = data_envio;
        this.atividade_idatividade = atividade_idatividade;
        this.grupotcc_idGrupo = grupotcc_idGrupo;
    }

    // Criar uma nova entrega
    static async create(nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo) {
        try {
            const [result] = await banco.execute(
                'INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo) VALUES (?, ?, ?, ?, ?)',
                [nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo]
            );
            return { 
                idEntrega: result.insertId, 
                nome_original, 
                nome_servidor, 
                caminho_arquivo, 
                data_envio: new Date(),
                atividade_idatividade, 
                grupotcc_idGrupo 
            };
        } catch (error) {
            throw error;
        }
    }

    // Listar todas as entregas
    static async readAll() {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                ORDER BY e.data_envio DESC
            `);
            return rows.map(row => ({
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar entrega por ID
    static async readByID(idEntrega) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE e.idEntrega = ?
            `, [idEntrega]);
            
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            };
        } catch (error) {
            throw error;
        }
    }

    // Atualizar entrega
    static async update(idEntrega, nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo) {
        try {
            const [result] = await banco.execute(
                'UPDATE entregas SET nome_original = ?, nome_servidor = ?, caminho_arquivo = ?, atividade_idatividade = ?, grupotcc_idGrupo = ? WHERE idEntrega = ?',
                [nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo, idEntrega]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar entrega
    static async delete(idEntrega) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM entregas WHERE idEntrega = ?',
                [idEntrega]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar entregas por atividade
    static async getByAtividade(atividade_idatividade) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE e.atividade_idatividade = ?
                ORDER BY e.data_envio DESC
            `, [atividade_idatividade]);
            
            return rows.map(row => ({
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar entregas por grupo
    static async getByGrupo(grupotcc_idGrupo) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE e.grupotcc_idGrupo = ?
                ORDER BY e.data_envio DESC
            `, [grupotcc_idGrupo]);
            
            return rows.map(row => ({
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar entregas por professor
    static async getByProfessor(idProfessor) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.idProfessor = ?
                ORDER BY e.data_envio DESC
            `, [idProfessor]);
            
            return rows.map(row => ({
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar entregas por curso
    static async getByCurso(idCurso) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE g.idCurso = ?
                ORDER BY e.data_envio DESC
            `, [idCurso]);
            
            return rows.map(row => ({
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            }));
        } catch (error) {
            throw error;
        }
    }

    // Verificar se grupo já fez entrega para uma atividade específica
    static async checkEntregaExists(grupotcc_idGrupo, atividade_idatividade) {
        try {
            const [rows] = await banco.execute(
                'SELECT COUNT(*) as total FROM entregas WHERE grupotcc_idGrupo = ? AND atividade_idatividade = ?',
                [grupotcc_idGrupo, atividade_idatividade]
            );
            return rows[0].total > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar última entrega de um grupo para uma atividade
    static async getLastEntregaByGrupoAtividade(grupotcc_idGrupo, atividade_idatividade) {
        try {
            const [rows] = await banco.execute(`
                SELECT e.*, a.nomeAtividade, g.tema, c.nomeCurso, p.nomeProfessor 
                FROM entregas e 
                LEFT JOIN atividade a ON e.atividade_idatividade = a.idatividade 
                LEFT JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE e.grupotcc_idGrupo = ? AND e.atividade_idatividade = ?
                ORDER BY e.data_envio DESC 
                LIMIT 1
            `, [grupotcc_idGrupo, atividade_idatividade]);
            
            if (rows.length === 0) return null;
            const row = rows[0];
            return {
                ...new Entregas(
                    row.idEntrega, 
                    row.nome_original, 
                    row.nome_servidor, 
                    row.caminho_arquivo, 
                    row.data_envio, 
                    row.atividade_idatividade, 
                    row.grupotcc_idGrupo
                ),
                nomeAtividade: row.nomeAtividade,
                tema: row.tema,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor
            };
        } catch (error) {
            throw error;
        }
    }

    // Contar entregas por data
    static async countByData(data) {
        try {
            const [rows] = await banco.execute(
                'SELECT COUNT(*) as total FROM entregas WHERE DATE(data_envio) = ?',
                [data]
            );
            return rows[0].total;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Entregas;