const banco = require('../../config/database');

class Atividade {
    constructor(idatividade, nomeAtividade, sequencia, dataEntrega, dataPostagem) {
        this.idatividade = idatividade;
        this.nomeAtividade = nomeAtividade;
        this.sequencia = sequencia;
        this.dataEntrega = dataEntrega;
        this.dataPostagem = dataPostagem;
    }

    // Criar uma nova atividade
    static async create(nomeAtividade, sequencia, dataEntrega, dataPostagem) {
        try {
            const [result] = await banco.execute(
                'INSERT INTO atividade (nomeAtividade, sequencia, dataEntrega, dataPostagem) VALUES (?, ?, ?, ?)',
                [nomeAtividade, sequencia, dataEntrega, dataPostagem]
            );
            return { 
                idatividade: result.insertId, 
                nomeAtividade, 
                sequencia, 
                dataEntrega, 
                dataPostagem 
            };
        } catch (error) {
            throw error;
        }
    }

    // Listar todas as atividades
    static async readAll() {
        try {
            const [rows] = await banco.execute('SELECT * FROM atividade ORDER BY sequencia');
            return rows.map(row => new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            ));
        } catch (error) {
            throw error;
        }
    }

    // Buscar atividade por ID
    static async readByID(idatividade) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM atividade WHERE idatividade = ?',
                [idatividade]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            );
        } catch (error) {
            throw error;
        }
    }

    // Atualizar atividade
    static async update(idatividade, nomeAtividade, sequencia, dataEntrega, dataPostagem) {
        try {
            const [result] = await banco.execute(
                'UPDATE atividade SET nomeAtividade = ?, sequencia = ?, dataEntrega = ?, dataPostagem = ? WHERE idatividade = ?',
                [nomeAtividade, sequencia, dataEntrega, dataPostagem, idatividade]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar atividade
    static async delete(idatividade) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM atividade WHERE idatividade = ?',
                [idatividade]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar atividades por sequência
    static async getBySequencia(sequencia) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM atividade WHERE sequencia = ?',
                [sequencia]
            );
            return rows.map(row => new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            ));
        } catch (error) {
            throw error;
        }
    }

    // Buscar atividades por data de entrega
    static async getByDataEntrega(dataEntrega) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM atividade WHERE dataEntrega = ? ORDER BY sequencia',
                [dataEntrega]
            );
            return rows.map(row => new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            ));
        } catch (error) {
            throw error;
        }
    }

    // Buscar atividades vencidas
    static async getVencidas() {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM atividade WHERE dataEntrega < CURDATE() ORDER BY dataEntrega DESC'
            );
            return rows.map(row => new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            ));
        } catch (error) {
            throw error;
        }
    }

    // Buscar próximas atividades
    static async getProximas() {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM atividade WHERE dataEntrega >= CURDATE() ORDER BY dataEntrega ASC'
            );
            return rows.map(row => new Atividade(
                row.idatividade, 
                row.nomeAtividade, 
                row.sequencia, 
                row.dataEntrega, 
                row.dataPostagem
            ));
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Atividade;