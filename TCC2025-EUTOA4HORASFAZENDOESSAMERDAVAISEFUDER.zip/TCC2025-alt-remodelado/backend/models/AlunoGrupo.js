const banco = require('../../config/database');

class AlunoGrupo {
    constructor(idGrupo, idAluno) {
        this.idGrupo = idGrupo;
        this.idAluno = idAluno;
    }

    // Adicionar aluno ao grupo
    static async create(idGrupo, idAluno) {
        try {
            await banco.execute(
                'INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES (?, ?)',
                [idGrupo, idAluno]
            );
            return { idGrupo, idAluno };
        } catch (error) {
            throw error;
        }
    }

    // Remover aluno do grupo
    static async delete(idGrupo, idAluno) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM aluno_grupo WHERE idGrupo = ? AND idAluno = ?',
                [idGrupo, idAluno]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar alunos de um grupo
    static async getAlunosByGrupo(idGrupo) {
        try {
            const [rows] = await banco.execute(`
                SELECT a.*, c.nomeCurso, ag.idGrupo 
                FROM aluno_grupo ag 
                JOIN aluno a ON ag.idAluno = a.idAluno 
                LEFT JOIN curso c ON a.idCurso = c.idCurso 
                WHERE ag.idGrupo = ?
            `, [idGrupo]);
            
            return rows.map(row => ({
                idAluno: row.idAluno,
                nomeAluno: row.nomeAluno,
                turma: row.turma,
                emailAluno: row.emailAluno,
                idCurso: row.idCurso,
                nomeCurso: row.nomeCurso,
                idGrupo: row.idGrupo
            }));
        } catch (error) {
            throw error;
        }
    }

    // Buscar grupos de um aluno
    static async getGruposByAluno(idAluno) {
        try {
            const [rows] = await banco.execute(`
                SELECT g.*, c.nomeCurso, p.nomeProfessor, ag.idAluno 
                FROM aluno_grupo ag 
                JOIN grupotcc g ON ag.idGrupo = g.idGrupo 
                LEFT JOIN curso c ON g.idCurso = c.idCurso 
                LEFT JOIN professor p ON g.idProfessor = p.idProfessor 
                WHERE ag.idAluno = ?
            `, [idAluno]);
            
            return rows.map(row => ({
                idGrupo: row.idGrupo,
                tema: row.tema,
                idCurso: row.idCurso,
                idProfessor: row.idProfessor,
                status: row.status,
                nomeCurso: row.nomeCurso,
                nomeProfessor: row.nomeProfessor,
                idAluno: row.idAluno
            }));
        } catch (error) {
            throw error;
        }
    }

    // Verificar se aluno já está em um grupo
    static async checkAlunoInGrupo(idAluno) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM aluno_grupo WHERE idAluno = ?',
                [idAluno]
            );
            return rows.length > 0;
        } catch (error) {
            throw error;
        }
    }

    // Contar quantos alunos tem em um grupo
    static async countAlunosInGrupo(idGrupo) {
        try {
            const [rows] = await banco.execute(
                'SELECT COUNT(*) as total FROM aluno_grupo WHERE idGrupo = ?',
                [idGrupo]
            );
            return rows[0].total;
        } catch (error) {
            throw error;
        }
    }

    // Remover todos os alunos de um grupo
    static async deleteAllFromGrupo(idGrupo) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM aluno_grupo WHERE idGrupo = ?',
                [idGrupo]
            );
            return result.affectedRows;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = AlunoGrupo;