const banco = require('../../config/database');

class Curso {
    constructor(idCurso, nomeCurso) {
        this.idCurso = idCurso;
        this.nomeCurso = nomeCurso;
    }

    // Criar um novo curso
    static async create(nomeCurso) {
        try {
            const [result] = await banco.execute(
                'INSERT INTO curso (nomeCurso) VALUES (?)',
                [nomeCurso]
            );
            return { idCurso: result.insertId, nomeCurso };
        } catch (error) {
            throw error;
        }
    }

    // Listar todos os cursos
    static async readAll() {
        try {
            const [rows] = await banco.execute('SELECT * FROM curso');
            return rows.map(row => new Curso(row.idCurso, row.nomeCurso));
        } catch (error) {
            throw error;
        }
    }

    // Buscar curso por ID
    static async readByID(idCurso) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM curso WHERE idCurso = ?',
                [idCurso]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return new Curso(row.idCurso, row.nomeCurso);
        } catch (error) {
            throw error;
        }
    }

    // Atualizar curso
    static async update(idCurso, nomeCurso) {
        try {
            const [result] = await banco.execute(
                'UPDATE curso SET nomeCurso = ? WHERE idCurso = ?',
                [nomeCurso, idCurso]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar curso
    static async delete(idCurso) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM curso WHERE idCurso = ?',
                [idCurso]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Curso;