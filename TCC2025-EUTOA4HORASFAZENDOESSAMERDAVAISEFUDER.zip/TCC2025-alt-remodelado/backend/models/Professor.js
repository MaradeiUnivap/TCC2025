const banco = require('../../config/database');

class Professor {
    constructor(idProfessor, nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) {
        this.idProfessor = idProfessor;
        this.nomeProfessor = nomeProfessor;
        this.emailProfessor = emailProfessor;
        this.senhaProfessor = senhaProfessor;
        this.isCoordenador = isCoordenador;
    }

    // Criar um novo professor
    static async create(nomeProfessor, emailProfessor, senhaProfessor, isCoordenador = 0) {
        try {
            const [result] = await banco.execute(
                'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)',
                [nomeProfessor, emailProfessor, senhaProfessor, isCoordenador]
            );
            return { 
                idProfessor: result.insertId, 
                nomeProfessor, 
                emailProfessor, 
                senhaProfessor, 
                isCoordenador 
            };
        } catch (error) {
            throw error;
        }
    }

    // Listar todos os professores
    static async readAll() {
        try {
            const [rows] = await banco.execute('SELECT * FROM professor');
            return rows.map(row => new Professor(
                row.idProfessor, 
                row.nomeProfessor, 
                row.emailProfessor, 
                row.senhaProfessor, 
                row.isCoordenador
            ));
        } catch (error) {
            throw error;
        }
    }

    // Buscar professor por ID
    static async readByID(idProfessor) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM professor WHERE idProfessor = ?',
                [idProfessor]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return new Professor(
                row.idProfessor, 
                row.nomeProfessor, 
                row.emailProfessor, 
                row.senhaProfessor, 
                row.isCoordenador
            );
        } catch (error) {
            throw error;
        }
    }

    // Buscar professor por email
    static async byEmail(emailProfessor) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM professor WHERE emailProfessor = ?',
                [emailProfessor]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return new Professor(
                row.idProfessor, 
                row.nomeProfessor, 
                row.emailProfessor, 
                row.senhaProfessor, 
                row.isCoordenador
            );
        } catch (error) {
            throw error;
        }
    }

    // Login do professor
    static async login(emailProfessor, senhaProfessor) {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                [emailProfessor, senhaProfessor]
            );
            if (rows.length === 0) return null;
            const row = rows[0];
            return new Professor(
                row.idProfessor, 
                row.nomeProfessor, 
                row.emailProfessor, 
                row.senhaProfessor, 
                row.isCoordenador
            );
        } catch (error) {
            throw error;
        }
    }

    // Atualizar professor
    static async update(idProfessor, nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) {
        try {
            const [result] = await banco.execute(
                'UPDATE professor SET nomeProfessor = ?, emailProfessor = ?, senhaProfessor = ?, isCoordenador = ? WHERE idProfessor = ?',
                [nomeProfessor, emailProfessor, senhaProfessor, isCoordenador, idProfessor]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Deletar professor
    static async delete(idProfessor) {
        try {
            const [result] = await banco.execute(
                'DELETE FROM professor WHERE idProfessor = ?',
                [idProfessor]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    // Buscar coordenadores
    static async getCoordenadores() {
        try {
            const [rows] = await banco.execute(
                'SELECT * FROM professor WHERE isCoordenador = 1'
            );
            return rows.map(row => new Professor(
                row.idProfessor, 
                row.nomeProfessor, 
                row.emailProfessor, 
                row.senhaProfessor, 
                row.isCoordenador
            ));
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Professor;