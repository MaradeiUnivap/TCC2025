const express = require('express');
const banco = require('../../config/database');
const router = express.Router();

router.get('/criar-atividade', (req, res) => {
    res.sendFile(__dirname + '/../frontend/criar-atividade.html');
});

router.get('/visualizar-atividades', function(req, res) {
    res.sendFile(__dirname + "/frontend/visualizar-atividades.html");
});

router.get('/criar-atividade', function(req, res) {
    res.sendFile(__dirname + "/frontend/criarAtividade.html");
});

// ROTA para buscar todas as atividades

module.exports = router;