const express = require('express');
const banco = require('../../config/database');
const router = express.Router();


// ROTA para exibir página de cadastro de coordenadores
router.get('/cadastro-coordenador', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroCoordenador.html");
});

// ROTA para cadastrar coordenador no banco (como professor com isCoordenador = true)
router.post('/cadastro-coordenador', (req, res) => {
    // Aceita ambos os formatos de campos (coordenador e professor)
    const nome = req.body.nomeCoordenador || req.body.nomeProfessor;
    const email = req.body.emailCoordenador || req.body.emailProfessor;
    const senha = req.body.senhaCoordenador || req.body.senhaProfessor;

    if (!nome || !email || !senha) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nome, email, senha, 1], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar coordenador:", erro);
            return res.status(500).send("Erro ao cadastrar coordenador.");
        }
        res.redirect('/login');
    });
});

// ROTA para exibir página de cadastro de alunos
router.get('/cadastro-aluno', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroAluno.html");
});

// ROTA para cadastrar aluno no banco
router.post('/cadastro-aluno', (req, res) => {
    const { nomeAluno, emailAluno, senhaAluno, idCurso } = req.body;

    if (!nomeAluno || !emailAluno || !senhaAluno || !idCurso) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeAluno, emailAluno, senhaAluno, idCurso], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar aluno:", erro);
            return res.status(500).send("Erro ao cadastrar aluno.");
        }
        res.redirect('/login');
    });
});

// ROTA para exibir página de cadastro de alunos
router.get('/cadastro-professor', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroProfessor.html");
});

// ROTA para cadastrar professor no banco (com isCoordenador = false)
router.post('/cadastro-professor', (req, res) => {
    const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;

    if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeProfessor, emailProfessor, senhaProfessor, 0], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar professor:", erro);
            return res.status(500).send("Erro ao cadastrar professor.");
        }
        res.redirect('/login');
    });
});
module.exports = router;