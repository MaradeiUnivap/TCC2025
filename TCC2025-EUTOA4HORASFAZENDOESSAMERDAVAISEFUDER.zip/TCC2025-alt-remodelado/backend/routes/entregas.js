const express = require('express');
const banco = require('../../config/database');
const upload = require('../../config/upload');
const router = express.Router();

router.post('/enviar-arquivo', upload.single('arquivoEnviado'), (req, res) => {
    const { idAtividade, idGrupo } = req.body;

    if (!req.file) {
        return res.status(400).send('Nenhum arquivo foi enviado.');
    }

    const nomeOriginal = req.file.originalname;
    const nomeServidor = req.file.filename;
    const caminhoArquivo = req.file.path;

    const sql = `
        INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo)
        VALUES (?, ?, ?, ?, ?)
    `;

    banco.query(sql, [nomeOriginal, nomeServidor, caminhoArquivo, idAtividade, idGrupo], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao salvar no banco:', erro);
            return res.status(500).send('Erro ao salvar as informações do arquivo.');
        }
        console.log('Arquivo salvo com sucesso!');
        res.send('Arquivo enviado com sucesso!');
    });
});

router.get('/download/:id', (req, res) => {
    const entregaId = req.params.id;
    const sql = 'SELECT caminho_arquivo, nome_original FROM entregas WHERE idEntrega = ?';

    banco.query(sql, [entregaId], (erro, resultados) => {
        if (erro || resultados.length === 0) {
            return res.status(404).send('Arquivo não encontrado.');
        }

        const caminho = resultados[0].caminho_arquivo;
        const nomeOriginal = resultados[0].nome_original;

        res.download(caminho, nomeOriginal, (errDownload) => {
            if (errDownload) {
                console.error("Erro no download:", errDownload);
            }
        });
    });
});
module.exports = router;