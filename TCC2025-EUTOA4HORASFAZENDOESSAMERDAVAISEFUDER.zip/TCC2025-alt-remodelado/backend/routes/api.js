const express = require('express');
const banco = require('../../config/database');
const router = express.Router();

router.get('/api/atividades', (req, res) => {
    const sql = 'SELECT * FROM atividade ORDER BY dataEntrega ASC';
    
    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar atividades:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// ROTA para buscar informações de uma atividade específica
router.get('/api/atividade/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM atividade WHERE idatividade = ?';
    
    banco.query(sql, [id], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar atividade:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        
        if (resultados.length === 0) {
            return res.status(404).json({ message: 'Atividade não encontrada' });
        }
        
        res.json(resultados[0]);
    });
});





router.get('/api/professores', (req, res) => {
    banco.query('SELECT idProfessor, nomeProfessor FROM professor ORDER BY nomeProfessor', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar professores:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

router.get('/api/cursos', (req, res) => {
    banco.query('SELECT idCurso, nomeCurso FROM curso ORDER BY nomeCurso', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar cursos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

router.get('/api/alunos/search', (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.json([]);
    }

    const sql = `
        SELECT *
        FROM aluno 
        WHERE nomeAluno LIKE ?;
    `;
    
    banco.query(sql, [`%${nome}%`], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar alunos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});


// ROTA: lista grupos com membros e quantidade de arquivos (resumo)
router.get('/api/grupos-resumo', (req, res) => {
  const sql = `
    SELECT 
      g.idGrupo,
      g.tema,
      g.status,
      GROUP_CONCAT(DISTINCT a.nomeAluno SEPARATOR '||') AS membros,
      COUNT(DISTINCT e.idEntrega) AS qtdArquivos
    FROM grupotcc g
    LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
    LEFT JOIN aluno a ON ag.idAluno = a.idAluno
    LEFT JOIN entregas e ON e.grupotcc_idGrupo = g.idGrupo
    GROUP BY g.idGrupo, g.tema, g.status
    ORDER BY g.tema ASC
  `;

  banco.query(sql, (erro, resultados) => {
    if (erro) {
      console.error('Erro ao buscar resumo de grupos:', erro);
      return res.status(500).json({ error: 'Erro interno' });
    }

    // transformar membros em array
    const dados = resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      status: r.status,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    }));

    res.json(dados);
  });
});

// ROTA para aprovar/recusar grupos (para coordenadores/professores)
router.put('/api/grupos/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!['aprovado', 'recusado'].includes(status)) {
        return res.status(400).json({ message: 'Status inválido' });
    }

    const sql = "UPDATE grupotcc SET status = ? WHERE idGrupo = ?";
    banco.query(sql, [status, id], (err) => {
        if (err) {
            console.error('Erro ao atualizar status do grupo:', err);
            return res.status(500).json({ message: 'Erro ao atualizar status do grupo' });
        }
        res.json({ message: `Status do grupo atualizado para ${status}` });
    });
});


router.get('/api/entregas', (req, res) => {
    const sql = `
        SELECT e.idEntrega, e.nome_original, e.data_envio, a.nomeAtividade, g.tema
        FROM entregas e
        INNER JOIN atividade a ON e.atividade_idatividade = a.idatividade
        INNER JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo
        ORDER BY e.data_envio DESC
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar entregas:', erro);
            return res.status(500).json({ erro: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});


router.get('/api/temas', (req, res) => {
    const { q } = req.query;

    if (!q || q.trim() === '') return res.json([]);

    const termo = `%${q.trim()}%`;

    const sql = `
        SELECT tema 
        FROM grupotcc 
        WHERE tema LIKE ? AND status = 'aprovado'
        LIMIT 5
    `;

    banco.query(sql, [termo], (err, resultados) => {
        if (err) {
            console.error('Erro ao buscar temas:', err);
            return res.status(500).json({ message: 'Erro interno.' });
        }

        res.json(resultados.map(r => r.tema));
    });
});


module.exports = router;