const express = require('express');
const banco = require('../../config/database');
const router = express.Router();

router.post('/login', function(req, res) {
    const email = req.body.email;
    const senha = req.body.senha;

    if (!email || !senha) {
        return res.status(400).send('Email e senha são obrigatórios!');
    }

    // checa aluno
    banco.query(
        'SELECT * FROM aluno WHERE emailAluno = ? AND senhaAluno = ?',
        [email, senha],
        (erro, resultados) => {
            if (erro) {
                console.error('Erro na consulta de alunos:', erro);
                return res.status(500).send('Erro interno no servidor');
            }
            if (resultados.length > 0) {
                if (req.session) {
                    req.session.user = { tipo: 'aluno', id: resultados[0].idAluno, nome: resultados[0].nomeAluno };
                }
                return res.redirect('/alunos');
            }

            // checa professor (agora inclui coordenadores)
            banco.query(
                'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                [email, senha],
                (erro2, resultados2) => {
                    if (erro2) {
                        console.error('Erro na consulta de professores:', erro2);
                        return res.status(500).send('Erro interno no servidor');
                    }

                    if (resultados2.length > 0) {
                        const user = resultados2[0];
                        let tipo = 'professor';
                        
                        // Verifica se é coordenador
                        if (user.isCoordenador) {
                            tipo = 'coordenador';
                        }
                        
                        if (req.session) {
                            req.session.user = { tipo: tipo, id: user.idProfessor, nome: user.nomeProfessor };
                        }
                        
                        if (tipo === 'coordenador') {
                            return res.redirect('/coordenadores');
                        } else {
                            return res.redirect('/professores');
                        }
                    }

                    return res.status(401).send('Credenciais inválidas');
                }
            );
        }
    );
});



module.exports = router;