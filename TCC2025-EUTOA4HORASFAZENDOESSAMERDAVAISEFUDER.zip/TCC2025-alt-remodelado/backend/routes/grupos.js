const express = require('express');
const banco = require('../../config/database');
const router = express.Router();

// ROTA para criar nova atividade
router.post('/api/atividades', function(req, res) {
    const { nomeAtividade, sequencia, dataEntrega } = req.body;

    if (!nomeAtividade || !sequencia || !dataEntrega) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios' });
    }

    const sql = 'INSERT INTO atividade (nomeAtividade, sequencia, dataEntrega, dataPostagem) VALUES (?, ?, ?, CURDATE())';
    
    banco.query(sql, [nomeAtividade, sequencia, dataEntrega], (erro, resultado) => {
        if (erro) {
            console.error('Erro ao criar atividade:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.status(201).json({ message: 'Atividade criada com sucesso!' });
    });
});

router.post('/api/grupos', (req, res) => {
    const { tema, idProfessor, idAlunos, idCurso } = req.body;

    if (!tema || !idProfessor || !idAlunos || idAlunos.length === 0 || !idCurso) {
        return res.status(400).json({ message: 'Dados incompletos para criar o grupo.' });
    }

    banco.getConnection((err, connection) => {
        if (err) {
            console.error('Erro ao obter conexão do banco:', err);
            return res.status(500).json({ message: 'Erro interno no servidor.' });
        }

        connection.beginTransaction(err => {
            if (err) {
                connection.release();
                return res.status(500).json({ message: 'Erro ao iniciar a transação.' });
            }

            // Inserir o novo grupo na tabela 'grupotcc'
            const sqlGrupo = 'INSERT INTO grupotcc (tema, idCurso, idProfessor, status) VALUES (?, ?, ?, "pendente")';
            connection.query(sqlGrupo, [tema, idCurso, idProfessor], (erro, resultadoGrupo) => {
                if (erro) {
                    return connection.rollback(() => {
                        connection.release();
                        console.error('Erro ao inserir grupo:', erro);
                        res.status(500).json({ message: 'Falha ao criar o grupo.' });
                    });
                }

                const idNovoGrupo = resultadoGrupo.insertId;

                // Preparar os dados para inserir na tabela 'aluno_grupo'
                const valoresAlunoGrupo = idAlunos.map(idAluno => [idNovoGrupo, idAluno]);
                const sqlAlunoGrupo = 'INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES ?';

                connection.query(sqlAlunoGrupo, [valoresAlunoGrupo], (erro, resultadoAlunos) => {
                    if (erro) {
                        return connection.rollback(() => {
                            connection.release();
                            console.error('Erro ao associar alunos ao grupo:', erro);
                            res.status(500).json({ message: 'Falha ao adicionar membros ao grupo.' });
                        });
                    }

                    // Se tudo deu certo, comita a transação
                    connection.commit(err => {
                        if (err) {
                            return connection.rollback(() => {
                                connection.release();
                                res.status(500).json({ message: 'Falha ao confirmar a criação do grupo.' });
                            });
                        }
                        
                        connection.release();
                        res.status(201).json({ message: 'Grupo criado com sucesso!' });
                    });
                });
            });
        });
    });
});
