const Professor = require('../models/Professor');

class ProfessorController {
    // Criar novo professor
    static async create(req, res) {
        try {
            const { nomeProfessor, emailProfessor, senhaProfessor, isCoordenador = 0 } = req.body;
            
            if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Nome, email e senha são obrigatórios' 
                });
            }

            // Verificar se email já existe
            const professorExistente = await Professor.byEmail(emailProfessor);
            if (professorExistente) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Email já está em uso' 
                });
            }

            const novoProfessor = await Professor.create(nomeProfessor, emailProfessor, senhaProfessor, isCoordenador);
            
            res.status(201).json({
                success: true,
                message: 'Professor criado com sucesso',
                data: novoProfessor
            });
        } catch (error) {
            console.error('Erro ao criar professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Listar todos os professores
    static async readAll(req, res) {
        try {
            const professores = await Professor.readAll();
            res.status(200).json({
                success: true,
                data: professores
            });
        } catch (error) {
            console.error('Erro ao listar professores:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar professor por ID
    static async readByID(req, res) {
        try {
            const { id } = req.params;
            const professor = await Professor.readByID(id);
            
            if (!professor) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Professor não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                data: professor
            });
        } catch (error) {
            console.error('Erro ao buscar professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Login do professor
    static async login(req, res) {
        try {
            const { emailProfessor, senhaProfessor } = req.body;
            
            if (!emailProfessor || !senhaProfessor) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Email e senha são obrigatórios' 
                });
            }

            const professor = await Professor.login(emailProfessor, senhaProfessor);
            
            if (!professor) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Email ou senha incorretos' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Login realizado com sucesso',
                data: {
                    idProfessor: professor.idProfessor,
                    nomeProfessor: professor.nomeProfessor,
                    emailProfessor: professor.emailProfessor,
                    isCoordenador: professor.isCoordenador
                }
            });
        } catch (error) {
            console.error('Erro no login do professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Atualizar professor
    static async update(req, res) {
        try {
            const { id } = req.params;
            const { nomeProfessor, emailProfessor, senhaProfessor, isCoordenador } = req.body;

            const sucesso = await Professor.update(id, nomeProfessor, emailProfessor, senhaProfessor, isCoordenador);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Professor não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Professor atualizado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Deletar professor
    static async delete(req, res) {
        try {
            const { id } = req.params;
            const sucesso = await Professor.delete(id);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Professor não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Professor deletado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar coordenadores
    static async getCoordenadores(req, res) {
        try {
            const coordenadores = await Professor.getCoordenadores();
            
            res.status(200).json({
                success: true,
                data: coordenadores
            });
        } catch (error) {
            console.error('Erro ao buscar coordenadores:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }
}

module.exports = ProfessorController;