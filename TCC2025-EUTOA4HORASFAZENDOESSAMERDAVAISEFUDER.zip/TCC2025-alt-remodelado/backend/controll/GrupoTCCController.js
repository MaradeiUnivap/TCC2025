const GrupoTCC = require('../models/GrupoTCC');
const AlunoGrupo = require('../models/AlunoGrupo');

class GrupoTCCController {
    // Criar novo grupo TCC
    static async create(req, res) {
        try {
            const { tema, idCurso, idProfessor, status = 'pendente' } = req.body;
            
            if (!tema || !idCurso || !idProfessor) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Tema, curso e professor são obrigatórios' 
                });
            }

            const novoGrupo = await GrupoTCC.create(tema, idCurso, idProfessor, status);
            
            res.status(201).json({
                success: true,
                message: 'Grupo TCC criado com sucesso',
                data: novoGrupo
            });
        } catch (error) {
            console.error('Erro ao criar grupo TCC:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Listar todos os grupos TCC
    static async readAll(req, res) {
        try {
            const grupos = await GrupoTCC.readAll();
            res.status(200).json({
                success: true,
                data: grupos
            });
        } catch (error) {
            console.error('Erro ao listar grupos TCC:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar grupo TCC por ID
    static async readByID(req, res) {
        try {
            const { id } = req.params;
            const grupo = await GrupoTCC.readByID(id);
            
            if (!grupo) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Grupo TCC não encontrado' 
                });
            }

            // Buscar alunos do grupo
            const alunos = await AlunoGrupo.getAlunosByGrupo(id);
            grupo.alunos = alunos;

            res.status(200).json({
                success: true,
                data: grupo
            });
        } catch (error) {
            console.error('Erro ao buscar grupo TCC:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Atualizar grupo TCC
    static async update(req, res) {
        try {
            const { id } = req.params;
            const { tema, idCurso, idProfessor, status } = req.body;

            const sucesso = await GrupoTCC.update(id, tema, idCurso, idProfessor, status);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Grupo TCC não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Grupo TCC atualizado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar grupo TCC:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Deletar grupo TCC
    static async delete(req, res) {
        try {
            const { id } = req.params;
            
            // Primeiro remover todos os alunos do grupo
            await AlunoGrupo.deleteAllFromGrupo(id);
            
            // Depois deletar o grupo
            const sucesso = await GrupoTCC.delete(id);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Grupo TCC não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Grupo TCC deletado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar grupo TCC:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar grupos por professor
    static async getByProfessor(req, res) {
        try {
            const { idProfessor } = req.params;
            const grupos = await GrupoTCC.getByProfessor(idProfessor);
            
            res.status(200).json({
                success: true,
                data: grupos
            });
        } catch (error) {
            console.error('Erro ao buscar grupos por professor:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Atualizar status do grupo
    static async updateStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;

            if (!status || !['pendente', 'aprovado', 'recusado'].includes(status)) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Status deve ser: pendente, aprovado ou recusado' 
                });
            }

            const sucesso = await GrupoTCC.updateStatus(id, status);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Grupo TCC não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Status do grupo atualizado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar status do grupo:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar grupos por status
    static async getByStatus(req, res) {
        try {
            const { status } = req.params;
            const grupos = await GrupoTCC.getByStatus(status);
            
            res.status(200).json({
                success: true,
                data: grupos
            });
        } catch (error) {
            console.error('Erro ao buscar grupos por status:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }
}

module.exports = GrupoTCCController;

