// controllers/AtividadeController.js
const Atividade = require('../models/Atividade');

class AtividadeController {
    // Listar todas as atividades
    static async index(req, res) {
        try {
            const atividades = await Atividade.readAll();
            res.json({
                success: true,
                data: atividades,
                message: 'Atividades listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao listar atividades:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar atividade por ID
    static async show(req, res) {
        try {
            const { id } = req.params;
            const atividade = await Atividade.readByID(id);
            
            if (!atividade) {
                return res.status(404).json({
                    success: false,
                    message: 'Atividade não encontrada'
                });
            }

            res.json({
                success: true,
                data: atividade,
                message: 'Atividade encontrada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar atividade:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Criar nova atividade
    static async store(req, res) {
        try {
            const { nomeAtividade, sequencia, dataEntrega, dataPostagem } = req.body;

            if (!nomeAtividade) {
                return res.status(400).json({
                    success: false,
                    message: 'Nome da atividade é obrigatório'
                });
            }

            const atividade = await Atividade.create(nomeAtividade, sequencia, dataEntrega, dataPostagem);
            
            res.status(201).json({
                success: true,
                data: atividade,
                message: 'Atividade criada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao criar atividade:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Atualizar atividade
    static async update(req, res) {
        try {
            const { id } = req.params;
            const { nomeAtividade, sequencia, dataEntrega, dataPostagem } = req.body;

            if (!nomeAtividade) {
                return res.status(400).json({
                    success: false,
                    message: 'Nome da atividade é obrigatório'
                });
            }

            const updated = await Atividade.update(id, nomeAtividade, sequencia, dataEntrega, dataPostagem);
            
            if (!updated) {
                return res.status(404).json({
                    success: false,
                    message: 'Atividade não encontrada'
                });
            }

            res.json({
                success: true,
                message: 'Atividade atualizada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar atividade:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Deletar atividade
    static async destroy(req, res) {
        try {
            const { id } = req.params;
            const deleted = await Atividade.delete(id);
            
            if (!deleted) {
                return res.status(404).json({
                    success: false,
                    message: 'Atividade não encontrada'
                });
            }

            res.json({
                success: true,
                message: 'Atividade deletada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar atividade:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar atividades por sequência
    static async getBySequencia(req, res) {
        try {
            const { sequencia } = req.params;
            const atividades = await Atividade.getBySequencia(sequencia);
            
            res.json({
                success: true,
                data: atividades,
                message: 'Atividades da sequência listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar atividades por sequência:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar atividades por data de entrega
    static async getByDataEntrega(req, res) {
        try {
            const { dataEntrega } = req.params;
            const atividades = await Atividade.getByDataEntrega(dataEntrega);
            
            res.json({
                success: true,
                data: atividades,
                message: 'Atividades da data de entrega listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar atividades por data de entrega:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar atividades vencidas
    static async getVencidas(req, res) {
        try {
            const atividades = await Atividade.getVencidas();
            
            res.json({
                success: true,
                data: atividades,
                message: 'Atividades vencidas listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar atividades vencidas:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar próximas atividades
    static async getProximas(req, res) {
        try {
            const atividades = await Atividade.getProximas();
            
            res.json({
                success: true,
                data: atividades,
                message: 'Próximas atividades listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar próximas atividades:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }
}

module.exports = AtividadeController;