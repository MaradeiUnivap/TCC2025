const Aluno = require('../models/Aluno');

class AlunoController {
    // Criar novo aluno
    static async create(req, res) {
        try {
            const { nomeAluno, turma, emailAluno, senhaAluno, idCurso } = req.body;
            
            if (!nomeAluno || !emailAluno || !senhaAluno) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Nome, email e senha são obrigatórios' 
                });
            }

            // Verificar se email já existe
            const alunoExistente = await Aluno.byEmail(emailAluno);
            if (alunoExistente) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Email já está em uso' 
                });
            }

            const novoAluno = await Aluno.create(nomeAluno, turma, emailAluno, senhaAluno, idCurso);
            
            res.status(201).json({
                success: true,
                message: 'Aluno criado com sucesso',
                data: novoAluno
            });
        } catch (error) {
            console.error('Erro ao criar aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Listar todos os alunos
    static async readAll(req, res) {
        try {
            const alunos = await Aluno.readAll();
            res.status(200).json({
                success: true,
                data: alunos
            });
        } catch (error) {
            console.error('Erro ao listar alunos:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar aluno por ID
    static async readByID(req, res) {
        try {
            const { id } = req.params;
            const aluno = await Aluno.readByID(id);
            
            if (!aluno) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Aluno não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                data: aluno
            });
        } catch (error) {
            console.error('Erro ao buscar aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Login do aluno
    static async login(req, res) {
        try {
            const { emailAluno, senhaAluno } = req.body;
            
            if (!emailAluno || !senhaAluno) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Email e senha são obrigatórios' 
                });
            }

            const aluno = await Aluno.login(emailAluno, senhaAluno);
            
            if (!aluno) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Email ou senha incorretos' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Login realizado com sucesso',
                data: {
                    idAluno: aluno.idAluno,
                    nomeAluno: aluno.nomeAluno,
                    emailAluno: aluno.emailAluno,
                    turma: aluno.turma,
                    idCurso: aluno.idCurso,
                    nomeCurso: aluno.nomeCurso
                }
            });
        } catch (error) {
            console.error('Erro no login do aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Atualizar aluno
    static async update(req, res) {
        try {
            const { id } = req.params;
            const { nomeAluno, turma, emailAluno, senhaAluno, idCurso } = req.body;

            const sucesso = await Aluno.update(id, nomeAluno, turma, emailAluno, senhaAluno, idCurso);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Aluno não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Aluno atualizado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Deletar aluno
    static async delete(req, res) {
        try {
            const { id } = req.params;
            const sucesso = await Aluno.delete(id);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Aluno não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Aluno deletado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar alunos por curso
    static async getByCurso(req, res) {
        try {
            const { idCurso } = req.params;
            const alunos = await Aluno.getByCurso(idCurso);
            
            res.status(200).json({
                success: true,
                data: alunos
            });
        } catch (error) {
            console.error('Erro ao buscar alunos por curso:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }
}
