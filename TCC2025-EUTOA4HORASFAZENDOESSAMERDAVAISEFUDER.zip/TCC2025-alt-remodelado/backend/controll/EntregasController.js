// controllers/EntregasController.js
const Entregas = require('../models/Entregas');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadPath = './uploads/entregas/';
        // Cria o diretório se não existir
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: function (req, file, cb) {
        // Gera um nome único para o arquivo
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const extension = path.extname(file.originalname);
        cb(null, 'entrega-' + uniqueSuffix + extension);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        // Permitir apenas certos tipos de arquivo
        const allowedTypes = /pdf|doc|docx|txt|zip|rar|ppt|pptx|xls|xlsx/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error('Tipo de arquivo não permitido'), false);
        }
    },
    limits: {
        fileSize: 50 * 1024 * 1024 // Limite de 50MB
    }
});

class EntregasController {
    // Listar todas as entregas
    static async index(req, res) {
        try {
            const entregas = await Entregas.readAll();
            res.json({
                success: true,
                data: entregas,
                message: 'Entregas listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao listar entregas:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar entrega por ID
    static async show(req, res) {
        try {
            const { id } = req.params;
            const entrega = await Entregas.readByID(id);
            
            if (!entrega) {
                return res.status(404).json({
                    success: false,
                    message: 'Entrega não encontrada'
                });
            }

            res.json({
                success: true,
                data: entrega,
                message: 'Entrega encontrada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar entrega:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Criar nova entrega (com upload de arquivo)
    static async store(req, res) {
        // Middleware do multer
        upload.single('arquivo')(req, res, async (err) => {
            if (err) {
                return res.status(400).json({
                    success: false,
                    message: 'Erro no upload do arquivo',
                    error: err.message
                });
            }

            try {
                const { atividade_idatividade, grupotcc_idGrupo } = req.body;
                
                if (!req.file) {
                    return res.status(400).json({
                        success: false,
                        message: 'Arquivo é obrigatório'
                    });
                }

                if (!atividade_idatividade || !grupotcc_idGrupo) {
                    return res.status(400).json({
                        success: false,
                        message: 'Atividade e grupo são obrigatórios'
                    });
                }

                const entrega = await Entregas.create(
                    req.file.originalname,
                    req.file.filename,
                    req.file.path,
                    atividade_idatividade,
                    grupotcc_idGrupo
                );
                
                res.status(201).json({
                    success: true,
                    data: entrega,
                    message: 'Entrega realizada com sucesso'
                });
            } catch (error) {
                console.error('Erro ao criar entrega:', error);
                // Remove arquivo se houve erro
                if (req.file) {
                    fs.unlink(req.file.path, (unlinkErr) => {
                        if (unlinkErr) console.error('Erro ao remover arquivo:', unlinkErr);
                    });
                }
                res.status(500).json({
                    success: false,
                    message: 'Erro interno do servidor',
                    error: error.message
                });
            }
        });
    }

    // Atualizar entrega
    static async update(req, res) {
        upload.single('arquivo')(req, res, async (err) => {
            if (err) {
                return res.status(400).json({
                    success: false,
                    message: 'Erro no upload do arquivo',
                    error: err.message
                });
            }

            try {
                const { id } = req.params;
                const { atividade_idatividade, grupotcc_idGrupo } = req.body;

                // Busca entrega atual para remover arquivo antigo se necessário
                const entregaAtual = await Entregas.readByID(id);
                if (!entregaAtual) {
                    return res.status(404).json({
                        success: false,
                        message: 'Entrega não encontrada'
                    });
                }

                let nome_original = entregaAtual.nome_original;
                let nome_servidor = entregaAtual.nome_servidor;
                let caminho_arquivo = entregaAtual.caminho_arquivo;

                // Se um novo arquivo foi enviado
                if (req.file) {
                    // Remove arquivo antigo
                    if (fs.existsSync(entregaAtual.caminho_arquivo)) {
                        fs.unlinkSync(entregaAtual.caminho_arquivo);
                    }
                    
                    nome_original = req.file.originalname;
                    nome_servidor = req.file.filename;
                    caminho_arquivo = req.file.path;
                }

                const updated = await Entregas.update(
                    id,
                    nome_original,
                    nome_servidor,
                    caminho_arquivo,
                    atividade_idatividade,
                    grupotcc_idGrupo
                );
                
                if (!updated) {
                    return res.status(404).json({
                        success: false,
                        message: 'Entrega não encontrada'
                    });
                }

                res.json({
                    success: true,
                    message: 'Entrega atualizada com sucesso'
                });
            } catch (error) {
                console.error('Erro ao atualizar entrega:', error);
                // Remove arquivo se houve erro
                if (req.file) {
                    fs.unlink(req.file.path, (unlinkErr) => {
                        if (unlinkErr) console.error('Erro ao remover arquivo:', unlinkErr);
                    });
                }
                res.status(500).json({
                    success: false,
                    message: 'Erro interno do servidor',
                    error: error.message
                });
            }
        });
    }

    // Deletar entrega
    static async destroy(req, res) {
        try {
            const { id } = req.params;
            
            // Busca entrega para remover arquivo
            const entrega = await Entregas.readByID(id);
            if (!entrega) {
                return res.status(404).json({
                    success: false,
                    message: 'Entrega não encontrada'
                });
            }

            const deleted = await Entregas.delete(id);
            
            if (deleted) {
                // Remove arquivo físico
                if (fs.existsSync(entrega.caminho_arquivo)) {
                    fs.unlinkSync(entrega.caminho_arquivo);
                }
            }

            res.json({
                success: true,
                message: 'Entrega deletada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar entrega:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Download de arquivo da entrega
    static async download(req, res) {
        try {
            const { id } = req.params;
            const entrega = await Entregas.readByID(id);
            
            if (!entrega) {
                return res.status(404).json({
                    success: false,
                    message: 'Entrega não encontrada'
                });
            }

            const filePath = path.resolve(entrega.caminho_arquivo);
            
            if (!fs.existsSync(filePath)) {
                return res.status(404).json({
                    success: false,
                    message: 'Arquivo não encontrado no servidor'
                });
            }

            res.download(filePath, entrega.nome_original);
        } catch (error) {
            console.error('Erro ao fazer download:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar entregas por atividade
    static async getByAtividade(req, res) {
        try {
            const { idAtividade } = req.params;
            const entregas = await Entregas.getByAtividade(idAtividade);
            
            res.json({
                success: true,
                data: entregas,
                message: 'Entregas da atividade listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar entregas por atividade:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar entregas por grupo
    static async getByGrupo(req, res) {
        try {
            const { idGrupo } = req.params;
            const entregas = await Entregas.getByGrupo(idGrupo);
            
            res.json({
                success: true,
                data: entregas,
                message: 'Entregas do grupo listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar entregas por grupo:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar entregas por professor
    static async getByProfessor(req, res) {
        try {
            const { idProfessor } = req.params;
            const entregas = await Entregas.getByProfessor(idProfessor);
            
            res.json({
                success: true,
                data: entregas,
                message: 'Entregas do professor listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar entregas por professor:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar entregas por curso
    static async getByCurso(req, res) {
        try {
            const { idCurso } = req.params;
            const entregas = await Entregas.getByCurso(idCurso);
            
            res.json({
                success: true,
                data: entregas,
                message: 'Entregas do curso listadas com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar entregas por curso:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Verificar se grupo já fez entrega para atividade
    static async checkEntregaExists(req, res) {
        try {
            const { idGrupo, idAtividade } = req.params;
            const exists = await Entregas.checkEntregaExists(idGrupo, idAtividade);
            
            res.json({
                success: true,
                data: { exists },
                message: exists ? 'Grupo já fez esta entrega' : 'Grupo ainda não fez esta entrega'
            });
        } catch (error) {
            console.error('Erro ao verificar entrega:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Buscar última entrega de um grupo para uma atividade
    static async getLastEntregaByGrupoAtividade(req, res) {
        try {
            const { idGrupo, idAtividade } = req.params;
            const entrega = await Entregas.getLastEntregaByGrupoAtividade(idGrupo, idAtividade);
            
            if (!entrega) {
                return res.status(404).json({
                    success: false,
                    message: 'Nenhuma entrega encontrada para este grupo e atividade'
                });
            }

            res.json({
                success: true,
                data: entrega,
                message: 'Última entrega encontrada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao buscar última entrega:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Contar entregas por data
    static async countByData(req, res) {
        try {
            const { data } = req.params;
            const total = await Entregas.countByData(data);
            
            res.json({
                success: true,
                data: { total, data },
                message: 'Contagem de entregas realizada com sucesso'
            });
        } catch (error) {
            console.error('Erro ao contar entregas por data:', error);
            res.status(500).json({
                success: false,
                message: 'Erro interno do servidor',
                error: error.message
            });
        }
    }

    // Middleware de upload para ser usado nas rotas
    static getUploadMiddleware() {
        return upload.single('arquivo');
    }
}

module.exports = EntregasController;