const AlunoGrupo = require('../models/AlunoGrupo');

class AlunoGrupoController {
    // Adicionar aluno ao grupo
    static async addAlunoToGrupo(req, res) {
        try {
            const { idGrupo, idAluno } = req.body;
            
            if (!idGrupo || !idAluno) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'ID do grupo e ID do aluno são obrigatórios' 
                });
            }

            // Verificar se aluno já está em algum grupo
            const alunoJaNoGrupo = await AlunoGrupo.checkAlunoInGrupo(idAluno);
            if (alunoJaNoGrupo) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Aluno já está em um grupo' 
                });
            }

            const resultado = await AlunoGrupo.create(idGrupo, idAluno);
            
            res.status(201).json({
                success: true,
                message: 'Aluno adicionado ao grupo com sucesso',
                data: resultado
            });
        } catch (error) {
            console.error('Erro ao adicionar aluno ao grupo:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Remover aluno do grupo
    static async removeAlunoFromGrupo(req, res) {
        try {
            const { idGrupo, idAluno } = req.params;
            
            const sucesso = await AlunoGrupo.delete(idGrupo, idAluno);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Relação aluno-grupo não encontrada' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Aluno removido do grupo com sucesso'
            });
        } catch (error) {
            console.error('Erro ao remover aluno do grupo:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar alunos de um grupo
    static async getAlunosByGrupo(req, res) {
        try {
            const { idGrupo } = req.params;
            const alunos = await AlunoGrupo.getAlunosByGrupo(idGrupo);
            
            res.status(200).json({
                success: true,
                data: alunos
            });
        } catch (error) {
            console.error('Erro ao buscar alunos do grupo:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar grupos de um aluno
    static async getGruposByAluno(req, res) {
        try {
            const { idAluno } = req.params;
            const grupos = await AlunoGrupo.getGruposByAluno(idAluno);
            
            res.status(200).json({
                success: true,
                data: grupos
            });
        } catch (error) {
            console.error('Erro ao buscar grupos do aluno:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }
}

module.exports = AlunoGrupoController;