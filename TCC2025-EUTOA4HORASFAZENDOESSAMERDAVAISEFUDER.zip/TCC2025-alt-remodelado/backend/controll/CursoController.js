const Curso = require('../models/Curso');

class CursoController {
    // Criar novo curso
    static async create(req, res) {
        try {
            const { nomeCurso } = req.body;
            
            if (!nomeCurso) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Nome do curso é obrigatório' 
                });
            }

            const novoCurso = await Curso.create(nomeCurso);
            
            res.status(201).json({
                success: true,
                message: 'Curso criado com sucesso',
                data: novoCurso
            });
        } catch (error) {
            console.error('Erro ao criar curso:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Listar todos os cursos
    static async readAll(req, res) {
        try {
            const cursos = await Curso.readAll();
            res.status(200).json({
                success: true,
                data: cursos
            });
        } catch (error) {
            console.error('Erro ao listar cursos:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Buscar curso por ID
    static async readByID(req, res) {
        try {
            const { id } = req.params;
            const curso = await Curso.readByID(id);
            
            if (!curso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Curso não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                data: curso
            });
        } catch (error) {
            console.error('Erro ao buscar curso:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Atualizar curso
    static async update(req, res) {
        try {
            const { id } = req.params;
            const { nomeCurso } = req.body;

            if (!nomeCurso) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Nome do curso é obrigatório' 
                });
            }

            const sucesso = await Curso.update(id, nomeCurso);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Curso não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Curso atualizado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao atualizar curso:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }

    // Deletar curso
    static async delete(req, res) {
        try {
            const { id } = req.params;
            const sucesso = await Curso.delete(id);
            
            if (!sucesso) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Curso não encontrado' 
                });
            }

            res.status(200).json({
                success: true,
                message: 'Curso deletado com sucesso'
            });
        } catch (error) {
            console.error('Erro ao deletar curso:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Erro interno do servidor' 
            });
        }
    }
}

module.exports = CursoController;
