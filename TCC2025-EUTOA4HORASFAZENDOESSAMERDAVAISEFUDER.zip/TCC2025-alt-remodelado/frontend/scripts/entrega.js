document.addEventListener('DOMContentLoaded', () => {
  const atividadesList = document.getElementById('atividades-list');
  const uploadSection = document.getElementById('upload-section');
  const selectedActivitySpan = document.getElementById('selected-activity');
  const idAtividadeInput = document.getElementById('idAtividade');
  const uploadForm = document.getElementById('upload-form');
  const arquivosList = document.getElementById('arquivos-list');
  const filterStatus = document.getElementById('filter-status');
  const filterCurso = document.getElementById('filter-curso');

  let atividades = [];
  let entregas = [];

  async function init() {
    await carregarEntregas();
    await carregarAtividades();
  }

  async function carregarAtividades() {
    try {
      const res = await fetch('/api/atividades');
      if (!res.ok) throw new Error('Erro ao buscar atividades');
      atividades = await res.json();
      preencherCursos();
      filtrarAtividades();
    } catch (err) {
      atividadesList.innerHTML = `
        <div class="empty-state"><i>❌</i><p>Erro ao carregar atividades</p></div>
      `;
    }
  }

  async function carregarEntregas() {
    try {
      const res = await fetch('/api/entregas');
      if (!res.ok) throw new Error('Erro ao buscar entregas');
      entregas = await res.json();
      renderEntregas(entregas);
    } catch (err) {
      console.error('Erro ao carregar entregas:', err);
    }
  }

  function preencherCursos() {
    const cursosUnicos = [...new Set(atividades.map(a => a.nomeCurso))];
    filterCurso.innerHTML = '<option value="all">Todos os cursos</option>';
    cursosUnicos.forEach(curso => {
      const option = document.createElement('option');
      option.value = curso;
      option.textContent = curso;
      filterCurso.appendChild(option);
    });
  }

  function filtrarAtividades() {
    const statusSelecionado = filterStatus.value;
    const cursoSelecionado = filterCurso.value;

    const atividadesFiltradas = atividades.filter(atividade => {
      const dataEntrega = new Date(atividade.dataEntrega);
      const hoje = new Date();
      const entrega = entregas.find(e => e.atividade_idatividade == atividade.idatividade);
      const status = entrega
        ? 'entregue'
        : dataEntrega < hoje
          ? 'atrasado'
          : 'pendente';

      const correspondeStatus = statusSelecionado === 'all' || status === statusSelecionado;
      const correspondeCurso = cursoSelecionado === 'all' || atividade.nomeCurso === cursoSelecionado;

      return correspondeStatus && correspondeCurso;
    });

    renderAtividades(atividadesFiltradas);
  }

  function renderAtividades(lista) {
    if (!lista.length) {
      atividadesList.innerHTML = `
        <div class="empty-state"><i>📚</i><p>Nenhuma atividade encontrada.</p></div>
      `;
      return;
    }

    const html = lista.map(atividade => {
      const dataEntrega = new Date(atividade.dataEntrega);
      const dataPostagem = new Date(atividade.dataPostagem);
      const hoje = new Date();
      const entrega = entregas.find(e => e.atividade_idatividade == atividade.idatividade);

      const status = entrega
        ? 'entregue'
        : dataEntrega < hoje
          ? 'atrasado'
          : 'pendente';

      const statusTexto = {
        pendente: 'Pendente',
        entregue: 'Entregue',
        atrasado: 'Atrasado'
      }[status];

      return `
        <div class="atividade-card" data-id="${atividade.idatividade}">
          <div class="atividade-header">
            <h3 class="atividade-title">${atividade.nomeAtividade}</h3>
            <span class="status-badge status-${status}">${statusTexto}</span>
          </div>
          <div class="atividade-details">
            <div class="detail-item">
              <span class="detail-label">Sequência</span>
              <span class="detail-value">${atividade.sequencia}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Curso</span>
              <span class="detail-value">${atividade.nomeCurso}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Data de Postagem</span>
              <span class="detail-value">${formatarData(dataPostagem)}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Data de Entrega</span>
              <span class="detail-value">${formatarData(dataEntrega)}</span>
            </div>
          </div>
          <button class="btn btn-primary btn-entregar" data-id="${atividade.idatividade}" data-nome="${atividade.nomeAtividade}">
            ${entrega ? 'Reenviar Trabalho' : 'Entregar Trabalho'}
          </button>
        </div>
      `;
    }).join('');

    atividadesList.innerHTML = html;
    adicionarEventosEntrega();
  }

  function renderEntregas(lista) {
    if (!lista.length) {
      arquivosList.innerHTML = `
        <div class="empty-state"><i>📂</i><p>Nenhum arquivo enviado ainda</p></div>
      `;
      return;
    }

    arquivosList.innerHTML = lista.map(entrega => `
      <div class="arquivo-item">
        <div>
          <div class="arquivo-name">${entrega.nome_original}</div>
          <div class="arquivo-date">Enviado em: ${formatarData(new Date(entrega.data_envio))}</div>
        </div>
        <a href="/download/${entrega.idEntrega}" class="btn btn-secondary">Download</a>
      </div>
    `).join('');
  }

  function adicionarEventosEntrega() {
    document.querySelectorAll('.btn-entregar').forEach(button => {
      button.addEventListener('click', () => {
        const id = button.dataset.id;
        const nome = button.dataset.nome;
        idAtividadeInput.value = id;
        selectedActivitySpan.textContent = nome;
        uploadSection.classList.add('active');
        uploadSection.scrollIntoView({ behavior: 'smooth' });
      });
    });
  }

  function formatarData(data) {
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const ano = data.getFullYear();
    return `${dia}/${mes}/${ano}`;
  }

  uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(uploadForm);

    try {
      const res = await fetch('/enviar-arquivo', {
        method: 'POST',
        body: formData
      });

      if (res.ok) {
        alert('Arquivo enviado com sucesso!');
        uploadForm.reset();
        await carregarEntregas();
        await carregarAtividades();
      } else {
        alert('Erro ao enviar o arquivo.');
      }
    } catch (err) {
      console.error('Erro ao enviar arquivo:', err);
      alert('Erro inesperado. Tente novamente.');
    }
  });

  // Adiciona os filtros
  filterStatus.addEventListener('change', filtrarAtividades);
  filterCurso.addEventListener('change', filtrarAtividades);

  init();
});
