-- MySQL Workbench Forward Engineering
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema tcc2025
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `tcc2025`;
CREATE SCHEMA IF NOT EXISTS `tcc2025` DEFAULT CHARACTER SET utf8mb4;
USE `tcc2025`;

-- -----------------------------------------------------
-- Table `tcc2025`.`curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`curso` (
  `idCurso` INT NOT NULL AUTO_INCREMENT,
  `nomeCurso` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`idCurso`))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`aluno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`aluno` (
  `idAluno` INT NOT NULL AUTO_INCREMENT,
  `nomeAluno` VARCHAR(100) NOT NULL,
  `turma` VARCHAR(10) NULL DEFAULT NULL,
  `emailAluno` VARCHAR(100) NULL DEFAULT NULL,
  `senhaAluno` VARCHAR(100) NOT NULL,
  `idCurso` INT NULL DEFAULT NULL,
  PRIMARY KEY (`idAluno`),
  INDEX `fk_aluno_curso_idx` (`idCurso` ASC),
  CONSTRAINT `fk_aluno_curso`
    FOREIGN KEY (`idCurso`)
    REFERENCES `tcc2025`.`curso` (`idCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`professor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`professor` (
  `idProfessor` INT NOT NULL AUTO_INCREMENT,
  `nomeProfessor` VARCHAR(100) NOT NULL,
  `emailProfessor` VARCHAR(100) NOT NULL,
  `senhaProfessor` VARCHAR(100) NOT NULL,
  `isCoordenador` TINYINT NULL DEFAULT 0,
  PRIMARY KEY (`idProfessor`))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`grupotcc`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`grupotcc` (
  `idGrupo` INT NOT NULL AUTO_INCREMENT,
  `tema` VARCHAR(255) NOT NULL,
  `idCurso` INT NOT NULL,
  `idProfessor` INT NOT NULL,
  `status` ENUM('pendente', 'aprovado', 'recusado') DEFAULT 'pendente',
  PRIMARY KEY (`idGrupo`),
  INDEX `fk_grupotcc_professor_idx` (`idProfessor` ASC),
  INDEX `fk_grupotcc_curso_idx` (`idCurso` ASC),
  CONSTRAINT `fk_grupotcc_professor`
    FOREIGN KEY (`idProfessor`)
    REFERENCES `tcc2025`.`professor` (`idProfessor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_grupotcc_curso`
    FOREIGN KEY (`idCurso`)
    REFERENCES `tcc2025`.`curso` (`idCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`aluno_grupo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`aluno_grupo` (
  `idGrupo` INT NOT NULL,
  `idAluno` INT NOT NULL,
  PRIMARY KEY (`idGrupo`, `idAluno`),
  INDEX `fk_aluno_grupo_aluno_idx` (`idAluno` ASC),
  INDEX `fk_aluno_grupo_grupo_idx` (`idGrupo` ASC),
  CONSTRAINT `fk_aluno_grupo_aluno`
    FOREIGN KEY (`idAluno`)
    REFERENCES `tcc2025`.`aluno` (`idAluno`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_aluno_grupo_grupo`
    FOREIGN KEY (`idGrupo`)
    REFERENCES `tcc2025`.`grupotcc` (`idGrupo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`atividade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`atividade` (
  `idatividade` INT NOT NULL AUTO_INCREMENT,
  `nomeAtividade` VARCHAR(45) NULL DEFAULT NULL,
  `sequencia` INT NULL DEFAULT NULL,
  `dataEntrega` DATE NULL DEFAULT NULL,
  `dataPostagem` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`idatividade`))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;

-- -----------------------------------------------------
-- Table `tcc2025`.`entregas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc2025`.`entregas` (
  `idEntrega` INT NOT NULL AUTO_INCREMENT,
  `nome_original` VARCHAR(255) NOT NULL,
  `nome_servidor` VARCHAR(255) NOT NULL,
  `caminho_arquivo` VARCHAR(255) NOT NULL,
  `data_envio` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `atividade_idatividade` INT NOT NULL,
  `grupotcc_idGrupo` INT NOT NULL,
  PRIMARY KEY (`idEntrega`),
  INDEX `fk_entregas_atividade1_idx` (`atividade_idatividade` ASC),
  INDEX `fk_entregas_grupotcc1_idx` (`grupotcc_idGrupo` ASC),
  CONSTRAINT `fk_entregas_atividade1`
    FOREIGN KEY (`atividade_idatividade`)
    REFERENCES `tcc2025`.`atividade` (`idatividade`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_entregas_grupotcc1`
    FOREIGN KEY (`grupotcc_idGrupo`)
    REFERENCES `tcc2025`.`grupotcc` (`idGrupo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
    
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4;





INSERT INTO `curso` (`idCurso`, `nomeCurso`) VALUES
(1, 'Informática'),
(2, 'Eletrônica'),
(3, 'Análises Clínicas'),
(4, 'Química'),
(5, 'Publicidade'),
(6, 'Administração');

-- Inserindo Professores (Alberson é coordenador)
INSERT INTO `professor` (`nomeProfessor`, `emailProfessor`, `senhaProfessor`, `isCoordenador`) VALUES
('Alberson', 'alberson@email.com', '1234', 1),
('Bruno',   'bruno@email.com',   '1234', 0),
('Hélio',   'helio@email.com',   '1234', 0),
('Wagner',  'wagner@email.com',  '1234', 0);


-- Inserindo Alunos (Turma: 3º I; Curso: 1 = Informática)
INSERT INTO `aluno` (`nomeAluno`, `turma`, `emailAluno`, `senhaAluno`, `idCurso`) VALUES
('Marco', '3º I', 'marco@email.com', '1234', 1),
('Davi',  '3º I', 'davi@email.com',  '1234', 1),
('Igor',  '3º I', 'igor@email.com',  '1234', 1);