const express = require('express');
const mysql = require('mysql');
const path = require('path');

const ProfessorRouter = require('./backend/roteador/ProfessorRouter');
const AlunoRouter = require('./backend/roteador/AlunoRouter');

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'frontend'))); 

const porta = 8000; 
const host = `http://localhost:${porta}`;

const banco = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});

const rotasProfessor = new ProfessorRouter(app, banco);
const rotasAlunos = new AlunoRouter(app, banco)

app.use('/professores',
    rotasProfessor.createRoutes()
);

app.use('/alunos',
    rotasAlunos.createRoutes()
);

app.listen(porta, () => {
    console.log(`Servidor rodando na porta ${porta}`);
    console.log(`Acesse em: ${host}`);
});
