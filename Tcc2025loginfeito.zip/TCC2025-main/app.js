const express = require('express');
const mysql = require('mysql');
const path = require('path');

const ProfessorRouter = require('./backend/roteador/ProfessorRouter');
const AlunoRouter = require('./backend/roteador/AlunoRouter');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend'))); 

const porta = 3000; 
const host = `http://localhost:${porta}`;

const banco = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});

const rotasProfessor = new ProfessorRouter(app, banco);
const rotasAlunos = new AlunoRouter(app, banco)

rotasProfessor.createRoutes(); 
rotasAlunos.createRoutes();


app.get('/login', function(req, res){
    res.sendFile(__dirname + "/frontend/login.html");  
});

app.post('/login', function(req, res) {
    const email = req.body.email;
    const senha = req.body.senha;

    if (!email || !senha) {
        return res.status(400).send('Email e senha são obrigatórios!');
    }

    banco.query(
        'SELECT * FROM aluno WHERE email = ? AND senhaAluno = ?',
        [email, senha],
        (erro, resultados) => {
            if (erro) {
                console.error('Erro na consulta de alunos:', erro);
                return res.status(500).send('Erro interno no servidor');
            }
            if (resultados.length > 0) {
                return res.redirect('/alunos');
            } else {
                banco.query(
                    'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                    [email, senha],
                    (erro2, resultados2) => {
                        if (erro2) {
                            console.error('Erro na consulta de professores:', erro2);
                            return res.status(500).send('Erro interno no servidor');
                        }

                        if (resultados2.length > 0) {
                            return res.redirect('/professores');
                        } else {
                            return res.status(401).send('Credenciais inválidas');
                        }
                    }
                );
            }
        }
    );
});



app.use('/professores', function(req, res) {
    res.sendFile(__dirname + "/frontend/professores.html")
});

app.use('/alunos', function(req, res) {
   res.sendFile(__dirname + "/frontend/alunos.html")
});

app.use('/', function(req, res){
    res.sendFile(__dirname + "/frontend/inicial.html");  
});

app.listen(porta, () => {
    console.log(`Servidor rodando na porta ${porta}`);
    console.log(`Acesse em: ${host}`);
});
