import openpyxl
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from ttkthemes import ThemedTk
import calendar
import os

ARQUIVO = "cadastro.xlsx"
COLUNAS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"]
TITULOS = [
    "NOME", "INSTAGRAM", "EMAIL", "CPF", "TELEFONE", "ENDEREÇO", "CEP",
    "ANO1aCOMPRA", "PGTO", "XALE", "NASCIMENTO", "NOVASCOMPRAS", "OUTRAS"
]


def criar_ou_abrir_arquivo():
    if os.path.exists(ARQUIVO):
        wb = openpyxl.load_workbook(ARQUIVO)
        sheet = wb.active
    else:
        wb = openpyxl.Workbook()
        sheet = wb.active
        for col, titulo in zip(COLUNAS, TITULOS):
            sheet[f"{col}1"] = titulo
    return wb, sheet


def obter_primeira_linha_vazia(sheet):
    row = 2
    while sheet[f"A{row}"].value:
        row += 1
    return row


def checar_dados(entrada, titulo):
    digitos = "".join(filter(str.isdigit, entrada))

    if titulo == "CEP" and len(digitos) == 8:
        return f"{digitos[:5]}-{digitos[5:]}"

    if titulo == "CPF" and len(digitos) == 11:
        return f"{digitos[:3]}.{digitos[3:6]}.{digitos[6:9]}-{digitos[9:]}"

    if titulo == "TELEFONE" and len(digitos) == 11:
        return f"({digitos[:2]}) {digitos[2:7]}-{digitos[7:]}"

    if titulo == "INSTAGRAM":
        return entrada if entrada.startswith("@") else f"@{entrada}"

    if titulo in ("ANO1aCOMPRA", "NASCIMENTO"):
        sep = "/" if "/" in entrada else ("-" if "-" in entrada else None)
        parts = entrada.split(sep) if sep else []
        if parts and len(parts) == 3 and all(p.isdigit() for p in parts):
            dia, mes, ano = parts
            dia = dia.zfill(2)
            mes = mes.zfill(2)
            if len(ano) == 2:
                if int(ano) <= 25:
                    ano = "20" + ano
                elif int(ano) > 25:
                    ano = "19" + ano

            if titulo == 'ANO1aCOMPRA':
                m = int(mes)
                return f"{calendar.month_name[m][:3]}./{ano[2:]}"
            return f"{dia}/{mes}/{ano}"

        if len(digitos) >= 6:
            dia = digitos[:2]
            mes = digitos[2:4]
            ano = digitos[4:]
            if len(ano) == 2:
                if int(ano) <= 25:
                    ano = "20" + ano
                elif int(ano) > 25:
                    ano = "19" + ano
            if titulo == 'ANO1aCOMPRA':
                m = int(mes)
                return f"{calendar.month_name[m][:3].lower()}./{ano[2:]}"
            return f"{dia}/{mes}/{ano}"

    return entrada


def cadastrar():
    wb, sheet = criar_ou_abrir_arquivo()
    linha = obter_primeira_linha_vazia(sheet)

    for col, titulo in zip(COLUNAS, TITULOS):
        valor = entries[titulo].get().strip()
        if valor:
            sheet[f"{col}{linha}"] = checar_dados(valor, titulo)

    wb.save(ARQUIVO)
    messagebox.showinfo("Sucesso", f"Dados salvos na linha {linha}!")
    for e in entries.values():
        e.delete(0, tk.END)

def go_to_next_entry(event):
    widgets = list(entries.values())
    try:
        idx = widgets.index(event.widget)  # Descobre qual campo está ativo
        widgets[(idx + 1) % len(widgets)].focus_set()  # Vai para o próximo campo (cíclico)
    except ValueError:
        pass  # Se não for um campo, ignora

def gerar_janela_cadastro():
    global entries
    root = ThemedTk(theme="adapta")
    root.title("Erika Pimenta Xales")
    root.set_theme("yaru")   # aplica o tema
    entries = {}

    for i, titulo in enumerate(TITULOS):
        ttk.Label(root, text=titulo).grid(row=i, column=0, sticky='e', padx=5, pady=2)
        ent = ttk.Entry(root, width=30)
        ent.grid(row=i, column=1, padx=5, pady=2)
        ent.bind('<Return>', go_to_next_entry)  # Enter para mudar o foco
        entries[titulo] = ent

    ttk.Button(root, text="Salvar Cadastro", command=cadastrar).grid(
        row=len(TITULOS), column=0, columnspan=2, pady=10)

    root.mainloop()



if __name__ == "__main__":
    gerar_janela_cadastro()
