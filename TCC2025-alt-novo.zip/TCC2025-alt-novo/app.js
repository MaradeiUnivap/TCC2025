const express = require('express');
const session = require('express-session');
const multer = require('multer');
const mysql = require('mysql');
const path = require('path');
const fs = require('fs');

const ProfessorRouter = require('./backend/roteador/ProfessorRouter');
const AlunoRouter = require('./backend/roteador/AlunoRouter');
const CoordenadorRouter = require('./backend/roteador/CoordenadorRouter');

const app = express();

// Configuração de sessão
app.use(session({
    secret: 'seu-secret-key-aqui', // Mude para uma chave secreta forte em produção
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // true apenas em HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 horas
    }
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend'))); 
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const porta = 3000; 
const host = `http://localhost:${porta}`;

const banco = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});

// Middleware de autenticação
const requireAuth = (tiposPermitidos = []) => {
    return (req, res, next) => {
        if (!req.session || !req.session.user) {
            return res.redirect('/login');
        }
        
        if (tiposPermitidos.length > 0 && !tiposPermitidos.includes(req.session.user.tipo)) {
            return res.status(403).send('Acesso negado');
        }
        
        next();
    };
};

// Middleware para verificar se já está logado
const redirectIfLoggedIn = (req, res, next) => {
    if (req.session && req.session.user) {
        switch (req.session.user.tipo) {
            case 'aluno':
                return res.redirect('/alunos');
            case 'professor':
                return res.redirect('/professores');
            case 'coordenador':
                return res.redirect('/coordenadores');
        }
    }
    next();
};

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const pasta = 'uploads/' + new Date().toISOString().split('T')[0];
        fs.mkdirSync(pasta, { recursive: true });
        cb(null, pasta);
    },
    filename: function (req, file, cb) {
        const nomeUnico = Date.now() + '-' + file.originalname;
        cb(null, nomeUnico);
    }
});

const upload = multer({ storage: storage });

const rotasProfessor = new ProfessorRouter(app, banco);
const rotasAlunos = new AlunoRouter(app, banco)
const rotasCoordenadores = new CoordenadorRouter(app, banco)

rotasProfessor.createRoutes(); 
rotasAlunos.createRoutes();
rotasCoordenadores.createRoutes();

// Rota de logout
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Erro ao destruir sessão:', err);
            return res.status(500).send('Erro ao fazer logout');
        }
        res.redirect('/login');
    });
});

app.get('/login', redirectIfLoggedIn, function(req, res){
    res.sendFile(__dirname + "/frontend/login.html");  
});

app.post('/login', function(req, res) {
    const email = req.body.email;
    const senha = req.body.senha;

    if (!email || !senha) {
        return res.status(400).send('Email e senha são obrigatórios!');
    }

    // checa aluno
    banco.query(
        'SELECT * FROM aluno WHERE emailAluno = ? AND senhaAluno = ?',
        [email, senha],
        (erro, resultados) => {
            if (erro) {
                console.error('Erro na consulta de alunos:', erro);
                return res.status(500).send('Erro interno no servidor');
            }
            if (resultados.length > 0) {
                req.session.user = { 
                    tipo: 'aluno', 
                    id: resultados[0].idAluno, 
                    nome: resultados[0].nomeAluno,
                    idCurso: resultados[0].idCurso 
                };
                return res.redirect('/alunos');
            }

            // checa professor (agora inclui coordenadores)
            banco.query(
                'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                [email, senha],
                (erro2, resultados2) => {
                    if (erro2) {
                        console.error('Erro na consulta de professores:', erro2);
                        return res.status(500).send('Erro interno no servidor');
                    }

                    if (resultados2.length > 0) {
                        const user = resultados2[0];
                        let tipo = 'professor';
                        
                        // Verifica se é coordenador
                        if (user.isCoordenador) {
                            tipo = 'coordenador';
                        }
                        
                        req.session.user = { 
                            tipo: tipo, 
                            id: user.idProfessor, 
                            nome: user.nomeProfessor 
                        };
                        
                        if (tipo === 'coordenador') {
                            return res.redirect('/coordenadores');
                        } else {
                            return res.redirect('/professores');
                        }
                    }

                    return res.status(401).send('Credenciais inválidas');
                }
            );
        }
    );
});

// API para dados do usuário logado
app.get('/api/user', requireAuth(), (req, res) => {
    res.json(req.session.user);
});

app.get('/api/professores', requireAuth(['professor', 'coordenador']), (req, res) => {
    banco.query('SELECT idProfessor, nomeProfessor FROM professor ORDER BY nomeProfessor', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar professores:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/cursos', requireAuth(), (req, res) => {
    banco.query('SELECT idCurso, nomeCurso FROM curso ORDER BY nomeCurso', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar cursos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/alunos/search', requireAuth(['professor', 'coordenador']), (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.json([]);
    }

    const sql = `
        SELECT *
        FROM aluno 
        WHERE nomeAluno LIKE ?;
    `;
    
    banco.query(sql, [`%${nome}%`], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar alunos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// ROTA para exibir página de visualização de atividades
app.get('/visualizar-atividades', function(req, res) {
    res.sendFile(__dirname + "/frontend/visualizar-atividades.html");
});

// ROTA para buscar todas as atividades
app.get('/api/atividades', requireAuth(), (req, res) => {
    const sql = 'SELECT * FROM atividade ORDER BY dataEntrega ASC';
    
    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar atividades:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// ROTA para buscar informações de uma atividade específica
app.get('/api/atividade/:id', requireAuth(), (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM atividade WHERE idatividade = ?';
    
    banco.query(sql, [id], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar atividade:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        
        if (resultados.length === 0) {
            return res.status(404).json({ message: 'Atividade não encontrada' });
        }
        
        res.json(resultados[0]);
    });
});

// ROTA para exibir página de manutenção
app.get('/coordenadores/atividades', requireAuth(['coordenador']), (req, res) => {
  res.sendFile(__dirname + '/frontend/manuAtividade.html');
});

// ROTA para exibir página de criação de atividade
app.get('/criar-atividade', requireAuth(['professor', 'coordenador']), function(req, res) {
    res.sendFile(__dirname + "/frontend/criarAtividade.html");
});

// ROTA para criar nova atividade
app.post('/api/atividades', requireAuth(['professor', 'coordenador']), function(req, res) {
    const { nomeAtividade, sequencia, dataEntrega } = req.body;

    if (!nomeAtividade || !sequencia || !dataEntrega) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios' });
    }

    const sql = 'INSERT INTO atividade (nomeAtividade, sequencia, dataEntrega, dataPostagem) VALUES (?, ?, ?, CURDATE())';
    
    banco.query(sql, [nomeAtividade, sequencia, dataEntrega], (erro, resultado) => {
        if (erro) {
            console.error('Erro ao criar atividade:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.status(201).json({ message: 'Atividade criada com sucesso!' });
    });
});

// Atualizar atividade
app.put('/api/atividade/:id', requireAuth(['professor', 'coordenador']), (req, res) => {
  const { id } = req.params;
  const { nomeAtividade, sequencia, dataEntrega } = req.body;

  if (!nomeAtividade || sequencia === undefined || !dataEntrega) {
    return res.status(400).json({ message: 'Campos obrigatórios faltando' });
  }

  const seqNum = Number(sequencia);
  if (!Number.isFinite(seqNum) || seqNum < 0) {
    return res.status(400).json({ message: 'Sequência inválida (deve ser >= 0)' });
  }

  const hoje = new Date().toISOString().split('T')[0];
  if (dataEntrega < hoje) {
    return res.status(400).json({ message: 'Data de entrega não pode ser anterior a hoje' });
  }

  const sql = 'UPDATE atividade SET nomeAtividade = ?, sequencia = ?, dataEntrega = ? WHERE idatividade = ?';
  banco.query(sql, [nomeAtividade, seqNum, dataEntrega, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar atividade:', err);
      return res.status(500).json({ message: 'Erro interno' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Atividade não encontrada' });
    }
    return res.json({ message: 'Atividade atualizada com sucesso' });
  });
});

// Deletar atividade (verifica entregas vinculadas)
app.delete('/api/atividade/:id', requireAuth(['professor', 'coordenador']), (req, res) => {
  const { id } = req.params;

  // evitar excluir se houver entregas vinculadas
  const checkSql = 'SELECT COUNT(*) AS cnt FROM entregas WHERE atividade_idatividade = ?';
  banco.query(checkSql, [id], (err, rows) => {
    if (err) {
      console.error('Erro ao checar entregas:', err);
      return res.status(500).json({ message: 'Erro interno' });
    }
    if (rows[0].cnt > 0) {
      return res.status(400).json({ message: 'Existem entregas vinculadas a essa atividade. Remova-as antes.' });
    }

    const delSql = 'DELETE FROM atividade WHERE idatividade = ?';
    banco.query(delSql, [id], (err2, result) => {
      if (err2) {
        console.error('Erro ao deletar atividade:', err2);
        return res.status(500).json({ message: 'Erro interno' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Atividade não encontrada' });
      }
      return res.json({ message: 'Atividade excluída com sucesso' });
    });
  });
});

// ROTA para exibir página de cadastro de coordenadores
app.get('/cadastro-coordenador', redirectIfLoggedIn, (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroCoordenador.html");
});

// ROTA para cadastrar coordenador no banco (como professor com isCoordenador = true)
app.post('/cadastro-coordenador', (req, res) => {
    // Aceita ambos os formatos de campos (coordenador e professor)
    const nome = req.body.nomeCoordenador || req.body.nomeProfessor;
    const email = req.body.emailCoordenador || req.body.emailProfessor;
    const senha = req.body.senhaCoordenador || req.body.senhaProfessor;

    if (!nome || !email || !senha) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nome, email, senha, 1], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar coordenador:", erro);
            return res.status(500).send("Erro ao cadastrar coordenador.");
        }
        res.redirect('/login');
    });
});

// ROTA para exibir página de cadastro de alunos
app.get('/cadastro-aluno', redirectIfLoggedIn, (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroAluno.html");
});

// ROTA para cadastrar aluno no banco
app.post('/cadastro-aluno', (req, res) => {
    const { nomeAluno, emailAluno, senhaAluno, idCurso } = req.body;

    if (!nomeAluno || !emailAluno || !senhaAluno || !idCurso) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeAluno, emailAluno, senhaAluno, idCurso], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar aluno:", erro);
            return res.status(500).send("Erro ao cadastrar aluno.");
        }
        res.redirect('/login');
    });
});

// ROTA para exibir página de cadastro de professores
app.get('/cadastro-professor', redirectIfLoggedIn, (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroProfessor.html");
});

// ROTA para cadastrar professor no banco (com isCoordenador = false)
app.post('/cadastro-professor', (req, res) => {
    const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;

    if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeProfessor, emailProfessor, senhaProfessor, 0], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar professor:", erro);
            return res.status(500).send("Erro ao cadastrar professor.");
        }
        res.redirect('/login');
    });
});

// ROTA para criar um novo grupo e associar os membros
app.post('/api/grupos', requireAuth(), (req, res) => {
    const { tema, idProfessor, idAlunos, idCurso } = req.body;

    if (!tema || !idProfessor || !idAlunos || idAlunos.length === 0 || !idCurso) {
        return res.status(400).json({ message: 'Dados incompletos para criar o grupo.' });
    }

    banco.getConnection((err, connection) => {
        if (err) {
            console.error('Erro ao obter conexão do banco:', err);
            return res.status(500).json({ message: 'Erro interno no servidor.' });
        }

        connection.beginTransaction(err => {
            if (err) {
                connection.release();
                return res.status(500).json({ message: 'Erro ao iniciar a transação.' });
            }

            // Inserir o novo grupo na tabela 'grupotcc'
            const sqlGrupo = 'INSERT INTO grupotcc (tema, idCurso, idProfessor, status) VALUES (?, ?, ?, "pendente")';
            connection.query(sqlGrupo, [tema, idCurso, idProfessor], (erro, resultadoGrupo) => {
                if (erro) {
                    return connection.rollback(() => {
                        connection.release();
                        console.error('Erro ao inserir grupo:', erro);
                        res.status(500).json({ message: 'Falha ao criar o grupo.' });
                    });
                }

                const idNovoGrupo = resultadoGrupo.insertId;

                // Preparar os dados para inserir na tabela 'aluno_grupo'
                const valoresAlunoGrupo = idAlunos.map(idAluno => [idNovoGrupo, idAluno]);
                const sqlAlunoGrupo = 'INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES ?';

                connection.query(sqlAlunoGrupo, [valoresAlunoGrupo], (erro, resultadoAlunos) => {
                    if (erro) {
                        return connection.rollback(() => {
                            connection.release();
                            console.error('Erro ao associar alunos ao grupo:', erro);
                            res.status(500).json({ message: 'Falha ao adicionar membros ao grupo.' });
                        });
                    }

                    // Se tudo deu certo, comita a transação
                    connection.commit(err => {
                        if (err) {
                            return connection.rollback(() => {
                                connection.release();
                                res.status(500).json({ message: 'Falha ao confirmar a criação do grupo.' });
                            });
                        }
                        
                        connection.release();
                        res.status(201).json({ message: 'Grupo criado com sucesso!' });
                    });
                });
            });
        });
    });
});

// ROTA: lista grupos com membros e quantidade de arquivos (resumo)
app.get('/api/grupos-resumo', requireAuth(['professor', 'coordenador']), (req, res) => {
  const sql = `
    SELECT 
      g.idGrupo,
      g.tema,
      g.status,
      GROUP_CONCAT(DISTINCT a.nomeAluno SEPARATOR '||') AS membros,
      COUNT(DISTINCT e.idEntrega) AS qtdArquivos
    FROM grupotcc g
    LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
    LEFT JOIN aluno a ON ag.idAluno = a.idAluno
    LEFT JOIN entregas e ON e.grupotcc_idGrupo = g.idGrupo
    GROUP BY g.idGrupo, g.tema, g.status
    ORDER BY g.tema ASC
  `;

  banco.query(sql, (erro, resultados) => {
    if (erro) {
      console.error('Erro ao buscar resumo de grupos:', erro);
      return res.status(500).json({ error: 'Erro interno' });
    }

    // transformar membros em array
    const dados = resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      status: r.status,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    }));

    res.json(dados);
  });
});

// ROTA para aprovar/recusar grupos (para coordenadores/professores)
app.put('/api/grupos/:id/status', requireAuth(['professor', 'coordenador']), (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!['aprovado', 'recusado'].includes(status)) {
        return res.status(400).json({ message: 'Status inválido' });
    }

    const sql = "UPDATE grupotcc SET status = ? WHERE idGrupo = ?";
    banco.query(sql, [status, id], (err) => {
        if (err) {
            console.error('Erro ao atualizar status do grupo:', err);
            return res.status(500).json({ message: 'Erro ao atualizar status do grupo' });
        }
        res.json({ message: `Status do grupo atualizado para ${status}` });
    });
});

// API para buscar grupos do aluno logado
app.get('/api/meus-grupos', requireAuth(['aluno']), (req, res) => {
    const idAluno = req.session.user.id;
    
    const sql = `
        SELECT g.idGrupo, g.tema, g.status
        FROM grupotcc g
        INNER JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
        WHERE ag.idAluno = ? AND g.status = 'aprovado'
        ORDER BY g.tema ASC
    `;
    
    banco.query(sql, [idAluno], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar grupos do aluno:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/temas', requireAuth(), (req, res) => {
  const { q } = req.query;
  console.log('GET /api/temas q=', JSON.stringify(q));

  if (!q || q.trim() === '') {
    return res.json([]);
  }

  const termo = `%${q.trim()}%`;
  const sql = `
    SELECT tema 
    FROM grupotcc 
    WHERE tema LIKE ? AND status = 'pendente'
    LIMIT 5
  `;
  banco.query(sql, [termo], (err, resultados) => {
    if (err) {
      console.error('Erro ao buscar temas:', err);
      return res.status(500).json({ message: 'Erro interno.' });
    }
    const temas = resultados.map(r => r.tema);
    res.json(temas);
  });
});

app.use('/professores', requireAuth(['professor']), function(req, res) {
    res.sendFile(__dirname + "/frontend/professores.html")
});

app.use('/alunos', requireAuth(['aluno']), function(req, res) {
   res.sendFile(__dirname + "/frontend/alunos.html")
});

app.use('/coordenadores', requireAuth(['coordenador']), function(req, res) {
   res.sendFile(__dirname + "/frontend/coordenadores.html")
});

app.use('/cadastrargrupo', requireAuth(['aluno']), function(req, res) {
   res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
});

app.use('/entrega', requireAuth(['aluno']), function(req, res) {
   res.sendFile(__dirname + "/frontend/entrega.html")
});

// Upload de arquivo agora identifica automaticamente o grupo do aluno
app.post('/enviar-arquivo', requireAuth(['aluno']), upload.single('arquivoEnviado'), (req, res) => {
    const { idAtividade } = req.body;
    const idAluno = req.session.user.id;

    if (!req.file) {
        return res.status(400).send('Nenhum arquivo foi enviado.');
    }

    if (!idAtividade) {
        return res.status(400).send('ID da atividade é obrigatório.');
    }

    // Primeiro, buscar o grupo do aluno
    const sqlGrupo = `
        SELECT g.idGrupo 
        FROM grupotcc g
        INNER JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
        WHERE ag.idAluno = ? AND g.status = 'aprovado'
        LIMIT 1
    `;

    banco.query(sqlGrupo, [idAluno], (erroGrupo, resultadosGrupo) => {
        if (erroGrupo) {
            console.error('Erro ao buscar grupo do aluno:', erroGrupo);
            return res.status(500).send('Erro ao buscar informações do grupo.');
        }

        if (resultadosGrupo.length === 0) {
            return res.status(400).send('Você não pertence a nenhum grupo aprovado.');
        }

        const idGrupo = resultadosGrupo[0].idGrupo;
        const nomeOriginal = req.file.originalname;
        const nomeServidor = req.file.filename;
        const caminhoArquivo = req.file.path;

        const sql = `
            INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo, aluno_idAluno)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        banco.query(sql, [nomeOriginal, nomeServidor, caminhoArquivo, idAtividade, idGrupo, idAluno], (erro, resultados) => {
            if (erro) {
                console.error('Erro ao salvar no banco:', erro);
                return res.status(500).send('Erro ao salvar as informações do arquivo.');
            }
            console.log('Arquivo salvo com sucesso!');
            res.json({ message: 'Arquivo enviado com sucesso!', nomeArquivo: nomeOriginal });
        });
    });
});

app.get('/api/entregas', requireAuth(['professor', 'coordenador']), (req, res) => {
    const sql = `
        SELECT 
            e.idEntrega, 
            e.nome_original, 
            e.data_envio, 
            e.atividade_idatividade,
            e.grupotcc_idGrupo,
            a.nomeAtividade, 
            g.tema,
            GROUP_CONCAT(DISTINCT al.nomeAluno SEPARATOR ', ') as membrosGrupo
        FROM entregas e
        INNER JOIN atividade a ON e.atividade_idatividade = a.idatividade
        INNER JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo
        LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
        LEFT JOIN aluno al ON ag.idAluno = al.idAluno
        GROUP BY e.idEntrega, e.nome_original, e.data_envio, e.atividade_idatividade, e.grupotcc_idGrupo, a.nomeAtividade, g.tema
        ORDER BY e.data_envio DESC
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar entregas:', erro);
            return res.status(500).json({ erro: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/download/:id', requireAuth(), (req, res) => {
    const entregaId = req.params.id;
    const sql = 'SELECT caminho_arquivo, nome_original FROM entregas WHERE idEntrega = ?';

    banco.query(sql, [entregaId], (erro, resultados) => {
        if (erro || resultados.length === 0) {
            return res.status(404).send('Arquivo não encontrado.');
        }

        const caminho = resultados[0].caminho_arquivo;
        const nomeOriginal = resultados[0].nome_original;

        res.download(caminho, nomeOriginal, (errDownload) => {
            if (errDownload) {
                console.error("Erro no download:", errDownload);
            }
        });
    });
});

app.use('/', redirectIfLoggedIn, function(req, res){
    res.sendFile(__dirname + "/frontend/inicial.html");  
});

app.listen(porta, () => {
    console.log('Conexão Estabelecida');
    console.log(`Servidor rodando na porta ${porta}`);
    console.log(`Acesse em: ${host}`);
});