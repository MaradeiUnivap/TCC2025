const express = require('express');
const CoordenadorControl = require('../controle/CoordenadorControl');
const CoordenadorMiddleware = require('../middleware/CoordenadorMiddleware');
const JwtMiddleware = require('../middleware/JWTMiddleware');

module.exports = class coordenadorRouter {
    constructor() {
        this._router = express.Router();
        this._coordenadorControl = new CoordenadorControl();
        this._coordenadorMiddleware = new CoordenadorMiddleware();
        this._jwtMiddleware = new JwtMiddleware();
    }

    createRoutes() {
        
        this.router.get('/',
            this.coordenadorControl.readAll
        );

        
        this.router.get('/:email',
            this.jwtMiddleware.validate,
            this.coordenadorControl.readById
        );

        // Criar novo coordenador
        this.router.post('/',
            this.jwtMiddleware.validate,
            this.coordenadorMiddleware.validate_emailCoordenador,
            this.coordenadorMiddleware.validate_senhaCoordenador,
            this.coordenadorMiddleware.isNotEmailCadastrado,
            this.coordenadorControl.create
        );

        // Atualizar coordenador
        this.router.put('/:email',
            this.jwtMiddleware.validate,
            this.coordenadorMiddleware.validate_emailCoordenador,
            this.coordenadorMiddleware.validate_senhaCoordenador,
            this.coordenadorControl.update
        );

        // Excluir coordenador
        this.router.delete('/:email',
            this.jwtMiddleware.validate,
            this.coordenadorControl.delete
        );

        return this._router;
    }

    get router() {
        return this._router;
    }

    set router(newRouter) {
        this._router = newRouter;
    }

    get coordenadorControl() {
        return this._coordenadorControl;
    }

    set coordenadorControl(newcoordenadorControl) {
        this._coordenadorControl = newcoordenadorControl;
    }

    get coordenadorMiddleware() {
        return this._coordenadorMiddleware;
    }

    set coordenadorMiddleware(newcoordenadorMiddleware) {
        this._coordenadorMiddleware = newcoordenadorMiddleware;
    }

    get jwtMiddleware() {
        return this._jwtMiddleware;
    }

    set jwtMiddleware(newJwtMiddleware) {
        this._jwtMiddleware = newJwtMiddleware;
    }
}
