const express = require('express');
const Coordenador = require('../modelo/Coordenador');
const jwtClass = require('../modelo/MeuTokenJWT'); 

module.exports = class CoordenadorControl {

    async login(request, response) {
        const coordenador = new Coordenador();

        coordenador.emailCoordenador = request.body.coordenador.email;
        coordenador.senha = request.body.coordenador.senha;

        const logou = await coordenador.login();

        if (logou === true) {
            const objResposta = {
                cod: 1,
                status: true,
                msg: 'Logado com sucesso',
                coordenador: {
                    email: coordenador.emailCoordenador
                }
            };
            response.status(200).send(objResposta);
        } else {
            const objResposta = {
                cod: 2,
                status: false,
                msg: "Erro ao efetuar login"
            };
            response.status(401).send(objResposta);
        }
    }

    async readAll(request, response) {
        const coordenador = new Coordenador();
        const dadosCoordenadores = await coordenador.readAll();

        const objResposta = {
            cod: 1,
            status: true,
            coordenadores: dadosCoordenadores
        };
        response.status(200).send(objResposta);
    }

    async readById(request, response) {
        const coordenador = new Coordenador();
        coordenador.emailCoordenador = request.params.email;

        const dados = await coordenador.readByID();

        const objResposta = {
            cod: 1,
            status: true,
            coordenadores: dados
        };
        response.status(200).send(objResposta);
    }

    async create(request, response) {
        const coordenador = new Coordenador();
        coordenador.nomeCoordenador = request.body.coordenador.nome;
        coordenador.emailCoordenador = request.body.coordenador.email;
        coordenador.senha = request.body.coordenador.senha;

        const sucesso = await coordenador.create();

        if (sucesso === true) {
            const objResposta = {
                cod: 1,
                status: true,
                coordenadores: [{
                    email: coordenador.emailCoordenador
                }]
            };
            response.status(201).send(objResposta);
        } else {
            const objResposta = {
                cod: 1,
                status: false,
                msg: "Falha ao cadastrar coordenador",
                coordenadores: [{
                    email: coordenador.emailCoordenador
                }]
            };
            response.status(200).send(objResposta);
        }
    }

    async update(request, response) {
        const coordenador = new Coordenador();
        coordenador.emailCoordenador = request.params.email;
        coordenador.senha = request.body.coordenador.senha;

        const atualizou = await coordenador.update();

        const objResposta = {
            cod: 1,
            status: atualizou,
            msg: atualizou ? "Atualizado com sucesso" : "Falha ao atualizar coordenador",
            coordenadores: [{
                email: coordenador.emailCoordenador
            }]
        };
        response.status(200).send(objResposta);
    }

    async delete(request, response) {
        const coordenador = new Coordenador();
        coordenador.emailCoordenador = request.params.email;

        const excluiu = await coordenador.delete();

        const objResposta = {
            cod: 1,
            status: excluiu,
            msg: excluiu ? "Excluído com sucesso" : "Falha ao excluir coordenador",
            coordenadores: [{
                email: coordenador.emailCoordenador
            }]
        };
        response.status(200).send(objResposta);
    }
};
