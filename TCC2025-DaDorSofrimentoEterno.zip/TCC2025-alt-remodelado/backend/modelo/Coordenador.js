
const Banco = require('./Banco');


module.exports = class Coordenador {
    
    constructor() {
        this._idCoordenador = null;
        this._nomeCoordenador = null; 
        this._turma = null; 
        this._emailCoordenador = null;
        this._senhaCoordenador = null; 
    }
    setidCurso(idCurso){
        this.idCurso = null;
    }
    getidCurso(idCurso){
        return this._idCurso;
    }
    
    async create() {
        const conexao = Banco.getConexao();
        const SQL = 'INSERT INTO coordenador (nomeCoordenador, emailCoordenador, senhaCoordenador) VALUES (?, ?, MD5(?));';

        try {
            const [result] = await conexao.promise().execute(SQL, [
                this._nomeCoordenador,
                this._emailCoordenador,
                this._senhaCoordenador
            ]);
            this._idCoordenador = result.insertId; 
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar o Coordenador:', error);
            return false;
        }
    }

   
    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM coordenador WHERE emailCoordenador = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailCoordenador]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Coordenador:', error);
            return false;
        }
    }

   
    async update() {
        const conexao = Banco.getConexao();
        const SQL = 'UPDATE coordenador SET senha = MD5(?) WHERE emailCoordenador = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._senhaCoordenador, this._emailCoordenador]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Coordenador:', error);
            return false;
        }
    }

    
    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM coordenador ORDER BY emailCoordenador;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Coordenadors:', error);
            return [];
        }
    }
    
 
    async readByID() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM coordenador WHERE idCoordenador = ?;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailCoordenador]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Coordenador pelo email:', error);
            return null;
        }
    }

    async isCoordenadorByEmail(emailCoordenador) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM coordenador WHERE emailCoordenador = ?;';  
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [emailCoordenador]); 
            return rows[0].qtd > 0;  
        } catch (error) {
            console.error('Erro ao verificar o email do Coordenador:', error);
            return false;  
        }
    }

    
    async login() {
        const conexao = Banco.getConexao();  
        const SQL = `
            SELECT COUNT(*) AS qtd, emailCoordenador
            FROM coordenador
            WHERE emailCoordenador = ? AND senha = MD5(?);
        `;  
    
        try {
           
            const [rows] = await conexao.promise().execute(SQL, [this._emailCoordenador, this._senha]);
    
            if (rows.length > 0 && rows[0].qtd === 1) {
                const tupla = rows[0];
                this._emailCoordenador = tupla.emailCoordenador;
    
                return true;  
            }
    
            return false; 
        } catch (error) {
            console.error('Erro ao realizar o login do Coordenador:', error);  
            return false;  
        }
    }
    
    
    set idCoordenador(novoIdCoordenador) {
        this._idPCoordenador = novoIdCoordenador;
    }
    get idCoordenador() {
        return this._idCoordenador;
    }

    set nomeCoordenador(novoNomeCoordenador) {
        this._nomeCoordenador = novoNomeCoordenador;
    }
    get nomeCoordenador() {
        return this._nomeCoordenador;
    }

    set emailCoordenador(novoEmailCoordenador) {
        this._emailCoordenador = novoEmailCoordenador;
    }
    get emailCoordenador() {
        return this._emailCoordenador;
    }

    set senha(novaSenha) {
        this._senha = novaSenha;
    }
    get senha() {
        return this._senha;
    }
};

