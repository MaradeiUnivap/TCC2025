const express = require('express');
const multer = require('multer');
const mysql = require('mysql');
const path = require('path');
const fs = require('fs');


const ProfessorRouter = require('./backend/roteador/ProfessorRouter');
const AlunoRouter = require('./backend/roteador/AlunoRouter');
const CoordenadorRouter = require('./backend/roteador/CoordenadorRouter');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend'))); 
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));




const porta = 3000; 
const host = `http://localhost:${porta}`;

const banco = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const pasta = 'uploads/' + new Date().toISOString().split('T')[0]; // exemplo: uploads/2025-08-21
        fs.mkdirSync(pasta, { recursive: true });
        cb(null, pasta);
    },
    filename: function (req, file, cb) {
        const nomeUnico = Date.now() + '-' + file.originalname;
        cb(null, nomeUnico);
    }
});


const upload = multer({ storage: storage });

const rotasProfessor = new ProfessorRouter(app, banco);
const rotasAlunos = new AlunoRouter(app, banco)
const rotasCoordenadores = new CoordenadorRouter(app, banco)

rotasProfessor.createRoutes(); 
rotasAlunos.createRoutes();
rotasCoordenadores.createRoutes();

app.get('/login', function(req, res){
    res.sendFile(__dirname + "/frontend/login.html");  
});

app.post('/login', function(req, res) {
    const email = req.body.email;
    const senha = req.body.senha;

    if (!email || !senha) {
        return res.status(400).send('Email e senha são obrigatórios!');
    }

    // checa aluno
    banco.query(
        'SELECT * FROM aluno WHERE emailAluno = ? AND senhaAluno = ?',
        [email, senha],
        (erro, resultados) => {
            if (erro) {
                console.error('Erro na consulta de alunos:', erro);
                return res.status(500).send('Erro interno no servidor');
            }
            if (resultados.length > 0) {
                // salva sessão se estiver configurada
                if (req.session) {
                    req.session.user = { tipo: 'aluno', id: resultados[0].idAluno, nome: resultados[0].nomeAluno };
                }
                return res.redirect('/alunos');
            }

            // checa professor
            banco.query(
                'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                [email, senha],
                (erro2, resultados2) => {
                    if (erro2) {
                        console.error('Erro na consulta de professores:', erro2);
                        return res.status(500).send('Erro interno no servidor');
                    }

                    if (resultados2.length > 0) {
                        if (req.session) {
                            req.session.user = { tipo: 'professor', id: resultados2[0].idProfessor, nome: resultados2[0].nomeProfessor };
                        }
                        return res.redirect('/professores');
                    }

                    // checa coordenador (corrigido nome da coluna de senha)
                    banco.query(
                        'SELECT * FROM coordenador WHERE emailCoordenador = ? AND senhaCoordenador = ?',
                        [email, senha],
                        (erro3, resultados3) => {
                            if (erro3) {
                                console.error('Erro na consulta de coordenadores:', erro3);
                                return res.status(500).send('Erro interno no servidor');
                            }

                            if (resultados3.length > 0) {
                                if (req.session) {
                                    req.session.user = { tipo: 'coordenador', id: resultados3[0].idcoordenador, nome: resultados3[0].nomeCoordenador };
                                }
                                return res.redirect('/coordenadores');
                            }

                            return res.status(401).send('Credenciais inválidas');
                        }
                    );
                }
            );
        }
    );
});



app.get('/api/professores', (req, res) => {
    banco.query('SELECT idProfessor, nomeProfessor FROM professor ORDER BY nomeProfessor', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar professores:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// POST /api/solicitacoes
app.post('/api/solicitacoes', (req, res) => {
    const { tema, idProfessor, idCurso, idAlunos } = req.body;

    const sql = "INSERT INTO SolicitacoesGrupo (tema, idCurso, idProfessor) VALUES (?, ?, ?)";
    banco.query(sql, [tema, idCurso, idProfessor], (err, result) => {
        if (err) return res.status(500).json({ message: 'Erro ao criar solicitação' });

        const idSolicitacao = result.insertId;
        const valores = idAlunos.map(idAluno => [idSolicitacao, idAluno]);

        const sqlMembros = "INSERT INTO SolicitacaoMembros (idSolicitacao, idAluno) VALUES ?";
        banco.query(sqlMembros, [valores], (err2) => {
            if (err2) return res.status(500).json({ message: 'Erro ao adicionar membros' });
            res.json({ message: 'Solicitação enviada com sucesso!' });
        });
    });
});

// GET /api/solicitacoes (para o professor ver as pendentes)
// GET /api/solicitacoes (para o professor ver as pendentes)
app.get('/api/solicitacoes', (req, res) => {
    const sql = `
        SELECT s.idSolicitacao, s.tema, c.nomeCurso, s.status,
               GROUP_CONCAT(a.nomeAluno SEPARATOR ', ') AS membros
        FROM SolicitacoesGrupo s
        JOIN curso c ON c.idCurso = s.idCurso
        JOIN SolicitacaoMembros sm ON sm.idSolicitacao = s.idSolicitacao
        JOIN aluno a ON a.idAluno = sm.idAluno
        WHERE s.status = 'pendente'
        GROUP BY s.idSolicitacao
    `;
    banco.query(sql, (err, rows) => {
        if (err) {
            console.error("Erro ao buscar solicitações:", err);
            return res.status(500).json({ message: 'Erro ao buscar solicitações' });
        }
        res.json(rows);
    });
});


// PUT /api/solicitacoes/:id/responder
app.put('/api/solicitacoes/:id/responder', (req, res) => {
    const { status } = req.body;
    const { id } = req.params;

    if (!['aprovado', 'recusado'].includes(status)) {
        return res.status(400).json({ message: 'Status inválido' });
    }

    const sql = "UPDATE SolicitacoesGrupo SET status=? WHERE idSolicitacao=?";
    banco.query(sql, [status, id], (err) => {
        if (err) return res.status(500).json({ message: 'Erro ao atualizar solicitação' });

        // Se aprovado, criar o GrupoTCC real
        if (status === 'aprovado') {
            const sqlDados = `
                SELECT * FROM SolicitacoesGrupo WHERE idSolicitacao=?`;
            banco.query(sqlDados, [id], (err2, rows) => {
                if (err2 || rows.length === 0) return;
                const { tema, idCurso, idProfessor } = rows[0];

                // cria grupo
                banco.query(
                    "INSERT INTO GrupoTCC (tema, idCurso, idProfessor) VALUES (?, ?, ?)",
                    [tema, idCurso, idProfessor],
                    (err3, result) => {
                        if (err3) return;
                        const idGrupo = result.insertId;

                        // copiar membros
                        banco.query("SELECT idAluno FROM SolicitacaoMembros WHERE idSolicitacao=?", [id],
                            (err4, membros) => {
                                if (err4) return;
                                const valores = membros.map(m => [idGrupo, m.idAluno]);
                                banco.query("INSERT INTO GrupoMembros (idGrupo, idAluno) VALUES ?", [valores]);
                            }
                        );
                    }
                );
            });
        }

        res.json({ message: `Solicitação ${status} com sucesso` });
    });
});


app.get('/api/cursos', (req, res) => {
    banco.query('SELECT idCurso, nomeCurso FROM curso ORDER BY nomeCurso', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar cursos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/alunos/search', (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.json([]);
    }

    // Este SQL seleciona apenas alunos que não existem na tabela aluno_grupo
    const sql = `
        SELECT *
        FROM aluno; 
    `;
    
    banco.query(sql, [`%${nome}%`], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar alunos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// ROTA para exibir página de cadastro de alunos
app.get('/cadastro-aluno', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroAluno.html");
});

// ROTA para cadastrar aluno no banco
app.post('/cadastro-aluno', (req, res) => {
    const { nomeAluno, emailAluno, senhaAluno, idCurso } = req.body;

    if (!nomeAluno || !emailAluno || !senhaAluno || !idCurso) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeAluno, emailAluno, senhaAluno, idCurso], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar aluno:", erro);
            return res.status(500).send("Erro ao cadastrar aluno.");
        }
        res.redirect('/login'); // Depois de cadastrar, manda pro login
    });
});

// ROTA para exibir página de cadastro de coordenadores
app.get('/cadastro-coordenador', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroCoordenador.html");
});

// ROTA para cadastrar coordenador no banco
app.post('/cadastro-coordenador', (req, res) => {
    const { nomeCoordenador, emailCoordenador, senhaCoordenador} = req.body;

    if (!nomeCoordenador || !emailCoordenador || !senhaCoordenador) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO coordenador (nomeCoordenador, emailCoordenador, senhaCoordenador) VALUES (?, ?, ?)';
    banco.query(sql, [nomeCoordenador, emailCoordenador, senhaCoordenador], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar coordenador:", erro);
            return res.status(500).send("Erro ao cadastrar coordenador.");
        }
        res.redirect('/login'); // Depois de cadastrar, manda pro login
    });
});

// ROTA para exibir página de cadastro de professores
app.get('/cadastro-professor', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroProfessor.html");
});

// ROTA para cadastrar professor no banco
app.post('/cadastro-professor', (req, res) => {
    const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;

    if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor) VALUES (?, ?, ?)';
    banco.query(sql, [nomeProfessor, emailProfessor, senhaProfessor], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar professor:", erro);
            return res.status(500).send("Erro ao cadastrar professor.");
        }
        res.redirect('/login');
    });
});


// ROTA para criar um novo grupo e associar os membros
app.post('/api/grupos', (req, res) => {
    const { tema, idProfessor, idAlunos } = req.body;

    if (!tema || !idProfessor || !idAlunos || idAlunos.length === 0) {
        return res.status(400).json({ message: 'Dados incompletos para criar o grupo.' });
    }

    // Usaremos uma transação para garantir que ambas as operações (criar grupo e adicionar membros)
    // sejam concluídas com sucesso. Se uma falhar, a outra é desfeita.
    banco.getConnection((err, connection) => {
        if (err) {
            console.error('Erro ao obter conexão do banco:', err);
            return res.status(500).json({ message: 'Erro interno no servidor.' });
        }

        connection.beginTransaction(err => {
            if (err) {
                connection.release();
                return res.status(500).json({ message: 'Erro ao iniciar a transação.' });
            }

            // 1. Inserir o novo grupo na tabela 'grupotcc'
            // Assumindo que o curso é fixo (ID 1) por enquanto. Você pode adaptar para pegar o curso do aluno logado.
            const sqlGrupo = 'INSERT INTO grupotcc (tema, idCurso, idProfessor) VALUES (?, ?, ?)';
            connection.query(sqlGrupo, [tema, 1, idProfessor], (erro, resultadoGrupo) => {
                if (erro) {
                    return connection.rollback(() => {
                        connection.release();
                        console.error('Erro ao inserir grupo:', erro);
                        res.status(500).json({ message: 'Falha ao criar o grupo.' });
                    });
                }

                const idNovoGrupo = resultadoGrupo.insertId;

                // 2. Preparar os dados para inserir na tabela 'aluno_grupo'
                const valoresAlunoGrupo = idAlunos.map(idAluno => [idNovoGrupo, idAluno]);
                const sqlAlunoGrupo = 'INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES ?';

                connection.query(sqlAlunoGrupo, [valoresAlunoGrupo], (erro, resultadoAlunos) => {
                    if (erro) {
                        return connection.rollback(() => {
                            connection.release();
                            console.error('Erro ao associar alunos ao grupo:', erro);
                            res.status(500).json({ message: 'Falha ao adicionar membros ao grupo.' });
                        });
                    }

                    // Se tudo deu certo, comita a transação
                    connection.commit(err => {
                        if (err) {
                            return connection.rollback(() => {
                                connection.release();
                                res.status(500).json({ message: 'Falha ao confirmar a criação do grupo.' });
                            });
                        }
                        
                        connection.release();
                        res.status(201).json({ message: 'Grupo criado com sucesso!' });
                    });
                });
            });
        });
    });
});

// ROTA: lista grupos com membros e quantidade de arquivos (resumo)
app.get('/api/grupos-resumo', (req, res) => {
  const sql = `
    SELECT 
      g.idGrupo,
      g.tema,
      GROUP_CONCAT(DISTINCT a.nomeAluno SEPARATOR '||') AS membros,
      COUNT(DISTINCT e.idEntrega) AS qtdArquivos
    FROM grupotcc g
    LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
    LEFT JOIN aluno a ON ag.idAluno = a.idAluno
    LEFT JOIN entregas e ON e.idAluno = a.idAluno
    GROUP BY g.idGrupo, g.tema
    ORDER BY g.tema ASC
  `;

  banco.query(sql, (erro, resultados) => {
    if (erro) {
      console.error('Erro ao buscar resumo de grupos:', erro);
      return res.status(500).json({ error: 'Erro interno' });
    }

    // transformar membros em array
    const dados = resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    }));

    res.json(dados);
  });
});

app.get('/api/temas', (req, res) => {
    const { q } = req.query; // recebe o termo digitado

    if (!q || q.trim() === '') return res.json([]);

    const termo = `%${q.trim()}%`; // LIKE para aproximar

    const sql = `
        SELECT tema 
        FROM grupotcc 
        WHERE tema LIKE ? 
        LIMIT 5
    `;

    banco.query(sql, [termo], (err, resultados) => {
        if (err) {
            console.error('Erro ao buscar temas:', err);
            return res.status(500).json({ message: 'Erro interno.' });
        }

        res.json(resultados.map(r => r.tema));
    });
});

app.use('/professores', function(req, res) {
    res.sendFile(__dirname + "/frontend/professores.html")
});


app.use('/alunos', function(req, res) {
   res.sendFile(__dirname + "/frontend/alunos.html")
});

app.use('/coordenadores', function(req, res) {
   res.sendFile(__dirname + "/frontend/coordenadores.html")
});

app.use('/cadastrargrupo', function(req, res) {
   res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
});

app.use('/cadastrargrupo', function(req, res) {
   res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
});
app.use('/entrega', function(req, res) {
   res.sendFile(__dirname + "/frontend/entrega.html")
});

app.post('/enviar-arquivo', upload.single('arquivoEnviado'), (req, res) => {
    const { idAluno } = req.body; // simulado. Ideal: usar sessão

    if (!req.file) {
        return res.status(400).send('Nenhum arquivo foi enviado.');
    }

    const nomeOriginal = req.file.originalname;
    const nomeServidor = req.file.filename;
    const caminhoArquivo = req.file.path;

    const sql = `
        INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, idAluno)
        VALUES (?, ?, ?, ?)
    `;

    banco.query(sql, [nomeOriginal, nomeServidor, caminhoArquivo, idAluno], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao salvar no banco:', erro);
            return res.status(500).send('Erro ao salvar as informações do arquivo.');
        }
        console.log('Arquivo salvo com sucesso!');
        res.send('Arquivo enviado com sucesso!');
    });
});



app.get('/api/entregas', (req, res) => {
    const sql = `
        SELECT e.idEntrega, e.nome_original, e.data_envio 
        FROM entregas e
        ORDER BY e.data_envio DESC
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar entregas:', erro);
            return res.status(500).json({ erro: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});


app.get('/download/:id', (req, res) => {
    const entregaId = req.params.id;
    const sql = 'SELECT caminho_arquivo, nome_original FROM entregas WHERE idEntrega = ?';

    banco.query(sql, [entregaId], (erro, resultados) => {
        if (erro || resultados.length === 0) {
            return res.status(404).send('Arquivo não encontrado.');
        }

        const caminho = resultados[0].caminho_arquivo;
        const nomeOriginal = resultados[0].nome_original;

        res.download(caminho, nomeOriginal, (errDownload) => {
            if (errDownload) {
                console.error("Erro no download:", errDownload);
            }
        });
    });
});


app.use('/', function(req, res){
    res.sendFile(__dirname + "/frontend/inicial.html");  
});

app.listen(porta, () => {
    console.log('Conexão Estabelecida');
    console.log(`Servidor rodando na porta ${porta}`);
    console.log(`Acesse em: ${host}`);
});

