const express = require('express');
const path = require('path');
// const session = require('express-session'); // simples para autenticação sem JWT

// Config
const { banco } = require('./backend/config/db');
const upload = require('./backend/config/upload');

// Middlewares
const errorHandler = require('./backend/middleware/errorHandler');
const autenticar = require('./backend/middleware/autenticar');
const permissoes = require('./backend/middleware/permissoes');

// Rotas
const professorRoutes = require('./backend/roteador/professorRoutes');
const alunoRoutes = require('./backend/roteador/alunoRoutes');
const coordenadorRoutes = require('./backend/roteador/coordenadorRoutes');
const atividadeRoutes = require('./backend/roteador/atividadeRoutes');
const grupoRoutes = require('./backend/roteador/grupoRoutes');
const entregaRoutes = require('./backend/roteador/entregaRoutes');
const authRoutes = require('./backend/roteador/authRoutes');
const cursoRoutes = require('./backend/roteador/cursoRoutes');
const temaRouter = require('./backend/roteador/temaRoutes');
const CargoMiddleware = require("./backend/middleware/JwtMiddleware");
const cargoMiddleware = new CargoMiddleware();
const app = express();
const porta = 3000;
const host = `http://localhost:${porta}`;
// Configurações globais
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/temas', temaRouter);
app.use('/api/cursos', cursoRoutes);



// Rotas principais
authRoutes(app, banco);          // login/logout
alunoRoutes(app, banco);         // cadastro aluno, busca aluno
professorRoutes(app, banco);     // cadastro/listagem professor
coordenadorRoutes(app, banco);   // cadastro coordenador
atividadeRoutes(app, banco, autenticar, permissoes); // CRUD de atividades
grupoRoutes(app, banco, autenticar, permissoes);     // grupos
entregaRoutes(app, banco, upload, autenticar);       // upload e download
professorRoutes(app, banco);




// Rotas estáticas
app.get('/alunos', (_, res) => res.sendFile(__dirname + "/frontend/alunos.html"));
app.get('/professores', (_, res) => res.sendFile(__dirname + "/frontend/professores.html"));
app.get('/coordenadores', (_, res) => res.sendFile(__dirname + "/frontend/coordenadores.html"));
// ✅ certo para páginas estáticas
app.get('/cadastrargrupo', (_, res) => 
  res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
);

app.get('/api/professor/:id', (req, res) =>
  grupoController.listarPorProfessor(banco, req, res)
);


app.get('/entrega', (_, res) =>
  res.sendFile(__dirname + "/frontend/entrega.html")
);

app.get('/criar-atividade', (_, res) =>
  res.sendFile(__dirname + "/frontend/criarAtividade.html")
);

app.get('/gerenciamentoGrupos', (_, res) =>
  res.sendFile(__dirname + "/frontend/gerenciamentoGrupos.html")
);

app.get('/visualizar-atividades', (_, res) =>
  res.sendFile(__dirname + "/frontend/visualizar-atividades.html")
);

app.get('/coordenadores/atividades', (_, res) =>
  res.sendFile(__dirname + "/frontend/manuAtividade.html")
);

app.use('/', function(req, res){
    res.sendFile(__dirname + "/frontend/inicial.html");  
});

app.get('/criar-atividade', (_, res) =>
  res.sendFile(__dirname + "/frontend/criarAtividade.html")
);

app.get('/cadastro-aluno', (_, res) =>
  res.sendFile(__dirname + "/frontend/cadastroAluno.html")
);

app.get('/cadastro-professor', (_, res) =>
  res.sendFile(__dirname + "/frontend/cadastroProfessor.html")
);

app.get('/cadastro-coordenador', (_, res) =>
  res.sendFile(__dirname + "/frontend/cadastroCoordenador.html")
);

// Middleware global de erro (vem por último!)
app.use(errorHandler);

// Inicialização
app.listen(porta, () => {
  console.log(`Servidor rodando: ${host}`);
});
