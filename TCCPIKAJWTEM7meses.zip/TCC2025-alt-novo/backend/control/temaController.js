// backend/controllers/TemaController.js
const TemaModel = require('../modelo/temaModel');

class TemaController {
    static async buscar(req, res) {
        const q = req.query.q || '';
        if (!q || q.length < 2) return res.json([]);

        try {
            console.log('Buscando temas para:', q);
            const temas = await TemaModel.buscarPorQuery(q);
            console.log('Resultado:', temas);
            res.json(temas);
        } catch (err) {
            console.error('Erro ao buscar temas:', err);
            res.status(500).json({ error: 'Erro ao buscar temas' });
        }
    }
}

module.exports = TemaController;
