const professorModel = require('../modelo/professorModel');

exports.cadastro = (banco, req, res) => {
  const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;
  if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
    return res.status(400).send("Campos obrigatórios");
  }
  professorModel.insert(banco, { nomeProfessor, emailProfessor, senhaProfessor, isCoordenador: 0 }, (erro) => {
    if (erro) return res.status(500).send("Erro ao cadastrar professor");
    res.redirect('/login');
  });
};

exports.getAll = (banco, callback) => {
  banco.query('SELECT idProfessor, nomeProfessor FROM professor', (erro, resultados) => {
    if (erro) return callback(erro);
    callback(null, resultados);
  });
};

exports.listar = (banco, req, res) => {
  professorModel.getAll(banco, (erro, resultados) => {
    if (erro) {
      console.error("Erro SQL:", erro); // 👈 mostra o erro real no terminal
      return res.status(500).json({ message: "Erro interno no servidor" });
    }
    res.json(resultados);
  });
};
