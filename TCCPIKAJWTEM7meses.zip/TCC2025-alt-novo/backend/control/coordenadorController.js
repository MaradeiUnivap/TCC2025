const professorModel = require('../modelo/professorModel');

exports.cadastro = (banco, req, res) => {
  const nome = req.body.nomeCoordenador || req.body.nomeProfessor;
  const email = req.body.emailCoordenador || req.body.emailProfessor;
  const senha = req.body.senhaCoordenador || req.body.senhaProfessor;

  if (!nome || !email || !senha) return res.status(400).send("Campos obrigatórios");

  professorModel.insert(banco, { nomeProfessor: nome, emailProfessor: email, senhaProfessor: senha, isCoordenador: 1 }, (erro) => {
    if (erro) return res.status(500).send("Erro ao cadastrar coordenador");
    res.redirect('/login');
  });
};
