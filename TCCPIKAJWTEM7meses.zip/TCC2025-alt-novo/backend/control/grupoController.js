const grupoModel = require('../modelo/grupoModel');

exports.criar = (banco, req, res) => {
  const { tema, idProfessor, idAlunos, idCurso } = req.body;
  if (!tema || !idProfessor || !idAlunos?.length || !idCurso) {
    return res.status(400).json({ message: "Dados incompletos" });
  }

  banco.getConnection((err, connection) => {
    if (err) return res.status(500).json({ message: "Erro conexão banco" });

    connection.beginTransaction(txErr => {
      if (txErr) {
        connection.release();
        return res.status(500).json({ message: "Erro transação" });
      }

      grupoModel.insert(connection, { tema, idCurso, idProfessor }, (erro, resultadoGrupo) => {
        if (erro) {
          return connection.rollback(() => {
            connection.release();
            res.status(500).json({ message: "Erro ao criar grupo" });
          });
        }

        const idNovoGrupo = resultadoGrupo.insertId;
        const valoresAlunoGrupo = idAlunos.map(idAluno => [idNovoGrupo, idAluno]);
        connection.query("INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES ?", [valoresAlunoGrupo], (erro2) => {
          if (erro2) {
            return connection.rollback(() => {
              connection.release();
              res.status(500).json({ message: "Erro ao associar alunos" });
            });
          }
          connection.commit(commitErr => {
            if (commitErr) {
              return connection.rollback(() => {
                connection.release();
                res.status(500).json({ message: "Erro commit" });
              });
            }
            connection.release();
            res.status(201).json({ message: "Grupo criado" });
          });
        });
      });
    });
  });
};

exports.resumo = (banco, req, res) => {
  grupoModel.getResumo(banco, (erro, resultados) => {
    if (erro) return res.status(500).json({ message: "Erro ao buscar resumo" });
    res.json(resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      status: r.status,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    })));
  });
};

exports.atualizarStatus = (banco, req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (!['aprovado', 'recusado'].includes(status)) {
    return res.status(400).json({ message: "Status inválido" });
  }
  grupoModel.updateStatus(banco, id, status, (erro) => {
    if (erro) return res.status(500).json({ message: "Erro update status" });
    res.json({ message: `Status atualizado para ${status}` });
  });
};

exports.resumo = (banco, req, res) => {
  grupoModel.getResumo(banco, {}, (erro, resultados) => {
    if (erro) return res.status(500).json({ message: "Erro ao buscar resumo" });
    res.json(resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      status: r.status,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    })));
  });
};

exports.listarPorProfessor = (banco, req, res) => {
  const idProfessor = req.params.id; // <-- muda aqui
  const { status } = req.query;
  console.log('idProfessor recebido:', idProfessor);

  if (!idProfessor) {
    return res.status(400).json({ message: "idProfessor é obrigatório" });
  }

  const filtros = { idProfessor };
  if (status) filtros.status = status;

  grupoModel.getResumo(banco, filtros, (erro, resultados) => {
    if (erro) {
      console.error('Erro no getResumo:', erro);
      return res.status(500).json({ message: "Erro ao buscar grupos" });
    }

    res.json(resultados.map(r => ({
      idGrupo: r.idGrupo,
      tema: r.tema,
      status: r.status,
      membros: r.membros ? r.membros.split('||') : [],
      qtdArquivos: r.qtdArquivos || 0
    })));
  });
};
