const atividadeModel = require('../modelo/atividadeModel');

exports.listar = (banco, req, res) => {
  atividadeModel.getAll(banco, (erro, resultados) => {
    if (erro) return res.status(500).json({ message: 'Erro ao buscar atividades' });
    res.json(resultados);
  });
};

exports.buscar = (banco, req, res) => {
  const id = req.params.id;
  atividadeModel.getById(banco, id, (erro, atividade) => {
    if (erro) return res.status(500).json({ message: 'Erro ao buscar atividade' });
    if (!atividade) return res.status(404).json({ message: 'Atividade não encontrada' });
    res.json(atividade);
  });
};

exports.criar = (banco, req, res) => {
  const { nomeAtividade, sequencia, dataEntrega } = req.body;
  if (!nomeAtividade || !sequencia || !dataEntrega) {
    return res.status(400).json({ message: 'Campos obrigatórios' });
  }

  atividadeModel.insert(banco, { nomeAtividade, sequencia, dataEntrega }, (erro) => {
    if (erro) return res.status(500).json({ message: 'Erro ao criar atividade' });
    res.status(201).json({ message: 'Atividade criada' });
  });
};

exports.atualizar = (banco, req, res) => {
  const id = req.params.id;
  const { nomeAtividade, sequencia, dataEntrega } = req.body;
  atividadeModel.update(banco, id, { nomeAtividade, sequencia, dataEntrega }, (erro, resultado) => {
    if (erro) return res.status(500).json({ message: 'Erro ao atualizar' });
    if (resultado.affectedRows === 0) return res.status(404).json({ message: 'Atividade não encontrada' });
    res.json({ message: 'Atualizada com sucesso' });
  });
};

exports.deletar = (banco, req, res) => {
  const id = req.params.id;
  console.log('Tentando deletar atividade com id:', id);

  banco.getConnection((err, connection) => {
    if (err) return res.status(500).json({ message: 'Erro na conexão com o banco' });

    connection.beginTransaction(txErr => {
      if (txErr) {
        connection.release();
        return res.status(500).json({ message: 'Erro ao iniciar transação' });
      }

      // 1. Deletar entregas associadas
      connection.query(
        'DELETE FROM entregas WHERE atividade_idatividade = ?',
        [id],
        (errEntregas) => {
          if (errEntregas) {
            return connection.rollback(() => {
              connection.release();
              console.error('Erro ao deletar entregas:', errEntregas);
              res.status(500).json({ message: 'Erro ao deletar entregas' });
            });
          }

          // 2. Deletar a própria atividade
          connection.query(
            'DELETE FROM atividade WHERE idatividade = ?',
            [id],
            (errAtividade, resultado) => {
              if (errAtividade) {
                return connection.rollback(() => {
                  connection.release();
                  console.error('Erro ao deletar atividade:', errAtividade);
                  res.status(500).json({ message: 'Erro ao deletar atividade' });
                });
              }

              if (resultado.affectedRows === 0) {
                return connection.rollback(() => {
                  connection.release();
                  res.status(404).json({ message: 'Atividade não encontrada' });
                });
              }

              // Commit da transação
              connection.commit(commitErr => {
                if (commitErr) {
                  return connection.rollback(() => {
                    connection.release();
                    console.error('Erro no commit:', commitErr);
                    res.status(500).json({ message: 'Erro ao finalizar exclusão' });
                  });
                }

                connection.release();
                res.json({ message: 'Atividade e entregas deletadas com sucesso' });
              });
            }
          );
        }
      );
    });
  });
};

