// backend/controllers/CursoController.js
const CursoModel = require('../modelo/cursoModel');

class CursoController {
    static async listar(req, res) {
        try {
            const cursos = await CursoModel.listarTodos();
            res.json(cursos);
        } catch (err) {
            console.error('Erro ao listar cursos:', err);
            res.status(500).json({ error: 'Erro ao listar cursos' });
        }
    }
}

module.exports = CursoController;
