const MeuTokenJWT = require("../modelo/MeuTokenJWT")

exports.login = (banco, req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) return res.status(400).send("Email e senha obrigatórios");

  // Checar aluno
  banco.query(
    "SELECT * FROM aluno WHERE emailAluno = ? AND senhaAluno = ?",
    [email, senha],
    (erro, resultados) => {
      if (erro) return res.status(500).send("Erro interno");
      if (erro) {
        console.error('Erro SQL login aluno:', erro);
        return res.status(500).send({ message: 'Erro interno no servidor' });
      }
      if (resultados.length > 0) {

       const meuTokenJWT = new MeuTokenJWT();
       const resp = {
       email:resultados[0].emailAluno,
       nome:resultados[0].nomeAluno,
       tipo:2
      };
      const token =  meuTokenJWT.gerarToken(resp);
            const resposta= {
                sucesso:true,
                data:{
                        email:resultados[0].emailAluno,
                        nome:resultados[0].nomeAluno
                  },
                tipo:2,
                token: token

            }
            return res.status(200).send(resposta);
      }

      // Checar professor / coordenador
      banco.query(
        "SELECT idProfessor, nomeProfessor, emailProfessor, isCoordenador FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?",
        [email, senha],
        (erro2, resultados2) => {
          if (erro2) return res.status(500).send("Erro interno");

          if (resultados2.length > 0) {
            const resposta= {
                sucesso:true,
                data: resultados2[0]
            }
            return res.status(200).send(resposta);
          }

                const resposta= {
                sucesso:false,
                error:{message: "usuario ou senha invalidos"}
            }
          res.status(401).send(resposta);
        }
      );
    }
  );
};