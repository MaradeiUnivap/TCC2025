const entregaModel = require('../modelo/entregaModel');

exports.enviarArquivo = (banco, req, res) => {
  const { idAtividade, idGrupo } = req.body;
  if (!req.file) return res.status(400).send("Nenhum arquivo enviado");

  const dados = {
    nomeOriginal: req.file.originalname,
    nomeServidor: req.file.filename,
    caminhoArquivo: req.file.path,
    idAtividade,
    idGrupo
  };

  entregaModel.insert(banco, dados, (erro) => {
    if (erro) return res.status(500).send("Erro salvar arquivo");
    res.send("Arquivo enviado com sucesso");
  });
};

exports.listar = (banco, req, res) => {
  entregaModel.getAll(banco, (erro, resultados) => {
    if (erro) return res.status(500).json({ message: "Erro listar entregas" });
    res.json(resultados);
  });
};

exports.download = (banco, req, res) => {
  const { id } = req.params;
  entregaModel.getById(banco, id, (erro, resultados) => {
    if (erro || resultados.length === 0) return res.status(404).send("Arquivo não encontrado");
    res.download(resultados[0].caminho_arquivo, resultados[0].nome_original);
  });
};
