const alunoModel = require('../modelo/alunoModel');

exports.cadastro = (banco, req, res) => {
  const { nomeAluno, emailAluno, senhaAluno, idCurso } = req.body;
  if (!nomeAluno || !emailAluno || !senhaAluno || !idCurso) {
    return res.status(400).send("Campos obrigatórios");
  }
  alunoModel.insert(banco, { nomeAluno, emailAluno, senhaAluno, idCurso }, (erro) => {
    if (erro) return res.status(500).send("Erro ao cadastrar aluno");
    res.redirect('/login');
  });
};

exports.buscarPorNome = (banco, req, res) => {
  const { nome } = req.query;
  if (!nome) return res.json([]);
  alunoModel.searchByName(banco, nome, (erro, resultados) => {
    if (erro) return res.status(500).json({ message: "Erro interno" });
    res.json(resultados);
  });
};