module.exports = (campos) => {
  return (req, res, next) => {
    for (let campo of campos) {
      if (!req.body[campo]) {
        return res.status(400).json({ message: `Campo obrigatório faltando: ${campo}` });
      }
    }
    next();
  };
};
