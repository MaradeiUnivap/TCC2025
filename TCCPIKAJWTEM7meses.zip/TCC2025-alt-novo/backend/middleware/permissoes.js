module.exports = (rolesPermitidos) => {
  return (req, res, next) => {
    if (!req.session?.user) {
      return res.status(401).json({ message: 'Não autenticado' });
    }
    if (!rolesPermitidos.includes(req.session.user.tipo)) {
      return res.status(403).json({ message: 'Acesso negado' });
    }
    next();
  };
};
