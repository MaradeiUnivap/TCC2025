exports.insert = (banco, { nomeProfessor, emailProfessor, senhaProfessor, isCoordenador }, callback) => {
  const sql = "INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor, isCoordenador) VALUES (?, ?, ?, ?)";
  banco.query(sql, [nomeProfessor, emailProfessor, senhaProfessor, isCoordenador], callback);
};

exports.getAll = (banco, callback) => {
  banco.query("SELECT idProfessor, nomeProfessor FROM professor ORDER BY nomeProfessor", callback);
};
