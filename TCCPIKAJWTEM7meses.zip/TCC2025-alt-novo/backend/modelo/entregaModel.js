exports.insert = (banco, dados, callback) => {
  const sql = `INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, atividade_idatividade, grupotcc_idGrupo)
               VALUES (?, ?, ?, ?, ?)`;
  banco.query(sql, [dados.nomeOriginal, dados.nomeServidor, dados.caminhoArquivo, dados.idAtividade, dados.idGrupo], callback);
};

exports.getAll = (banco, callback) => {
  const sql = `
    SELECT e.idEntrega, e.nome_original, e.data_envio, e.atividade_idatividade,
           e.grupotcc_idGrupo, a.nomeAtividade, g.tema
    FROM entregas e
    INNER JOIN atividade a ON e.atividade_idatividade = a.idatividade
    INNER JOIN grupotcc g ON e.grupotcc_idGrupo = g.idGrupo
    ORDER BY e.data_envio DESC
  `;
  banco.query(sql, callback);
};

exports.getById = (banco, id, callback) => {
  banco.query("SELECT caminho_arquivo, nome_original FROM entregas WHERE idEntrega = ?", [id], callback);
};
