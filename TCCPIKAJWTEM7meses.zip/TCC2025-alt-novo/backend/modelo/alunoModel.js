exports.insert = (banco, { nomeAluno, emailAluno, senhaAluno, idCurso }, callback) => {
  const sql = "INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?)";
  banco.query(sql, [nomeAluno, emailAluno, senhaAluno, idCurso], callback);
};

exports.searchByName = (banco, nome, callback) => {
  banco.query("SELECT * FROM aluno WHERE nomeAluno LIKE ?", [`%${nome}%`], callback);
};