// backend/models/CursoModel.js
const { banco } = require('../config/db');

class CursoModel {
    static async listarTodos() {
        return new Promise((resolve, reject) => {
            const sql = `SELECT idCurso, nomeCurso FROM curso ORDER BY nomeCurso`;
            banco.query(sql, (err, results) => {
                if (err) return reject(err);
                resolve(results);
            });
        });
    }
}

module.exports = CursoModel;
