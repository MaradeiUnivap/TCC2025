exports.getAll = (banco, callback) => {
  banco.query('SELECT * FROM atividade ORDER BY dataEntrega ASC', callback);
};

exports.getById = (banco, id, callback) => {
  banco.query('SELECT * FROM atividade WHERE idatividade = ?', [id], (err, results) => {
    callback(err, results[0]);
  });
};

exports.insert = (banco, { nomeAtividade, sequencia, dataEntrega }, callback) => {
  const sql = 'INSERT INTO atividade (nomeAtividade, sequencia, dataEntrega, dataPostagem) VALUES (?, ?, ?, CURDATE())';
  banco.query(sql, [nomeAtividade, sequencia, dataEntrega], callback);
};

exports.update = (banco, id, { nomeAtividade, sequencia, dataEntrega }, callback) => {
  const sql = 'UPDATE atividade SET nomeAtividade = ?, sequencia = ?, dataEntrega = ? WHERE idatividade = ?';
  banco.query(sql, [nomeAtividade, sequencia, dataEntrega, id], callback);
};

exports.remove = (banco, id, callback) => {
  banco.query('DELETE FROM atividade WHERE idatividade = ?', [id], callback);
};
