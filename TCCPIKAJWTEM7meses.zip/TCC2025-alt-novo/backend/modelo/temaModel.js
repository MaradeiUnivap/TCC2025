// backend/models/TemaModel.js
const { banco } = require('../config/db');

class TemaModel {
    static async buscarPorQuery(query) {
        return new Promise((resolve, reject) => {
            const sql = `SELECT DISTINCT tema FROM grupotcc WHERE tema LIKE ? LIMIT 10`;
            banco.query(sql, [`%${query}%`], (err, results) => {
                if (err) return reject(err);
                const temas = results.map(r => r.tema);
                resolve(temas);
            });
        });
    }
}

module.exports = TemaModel;
