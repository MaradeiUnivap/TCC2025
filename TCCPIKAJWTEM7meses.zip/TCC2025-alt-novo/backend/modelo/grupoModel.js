exports.insert = (banco, { tema, idCurso, idProfessor }, callback) => {
  const sql = 'INSERT INTO grupotcc (tema, idCurso, idProfessor, status) VALUES (?, ?, ?, "pendente")';
  banco.query(sql, [tema, idCurso, idProfessor], callback);
};

exports.updateStatus = (banco, id, status, callback) => {
  banco.query("UPDATE grupotcc SET status = ? WHERE idGrupo = ?", [status, id], callback);
};

// Adicionar esta função ao grupoModel.js
exports.getByProfessor = (banco, idProfessor, callback) => {
  const sql = `
    SELECT g.idGrupo, g.tema, g.status,
      GROUP_CONCAT(DISTINCT a.nomeAluno SEPARATOR '||') AS membros,
      COUNT(DISTINCT e.idEntrega) AS qtdArquivos
    FROM grupotcc g
    LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
    LEFT JOIN aluno a ON ag.idAluno = a.idAluno
    LEFT JOIN entregas e ON e.grupotcc_idGrupo = g.idGrupo
    WHERE g.idProfessor = ?
    GROUP BY g.idGrupo, g.tema, g.status
    ORDER BY g.status, g.tema ASC
  `;
  banco.query(sql, [idProfessor], callback);
};

exports.getResumo = (banco, filtros, callback) => {
  let sql = `
    SELECT g.idGrupo, g.tema, g.status,
      GROUP_CONCAT(DISTINCT a.nomeAluno SEPARATOR '||') AS membros,
      COUNT(DISTINCT e.idEntrega) AS qtdArquivos
    FROM grupotcc g
    LEFT JOIN aluno_grupo ag ON g.idGrupo = ag.idGrupo
    LEFT JOIN aluno a ON ag.idAluno = a.idAluno
    LEFT JOIN entregas e ON e.grupotcc_idGrupo = g.idGrupo
  `;

  let whereConditions = [];
  let queryParams = [];

  if (filtros.idProfessor) {
    whereConditions.push('g.idProfessor = ?');
    queryParams.push(filtros.idProfessor);
  }

  if (filtros.status) {
    whereConditions.push('g.status = ?');
    queryParams.push(filtros.status);
  }

  if (whereConditions.length > 0) {
    sql += ' WHERE ' + whereConditions.join(' AND ');
  }

  sql += `
    GROUP BY g.idGrupo, g.tema, g.status
    ORDER BY g.tema ASC
  `;

  banco.query(sql, queryParams, callback);
};
