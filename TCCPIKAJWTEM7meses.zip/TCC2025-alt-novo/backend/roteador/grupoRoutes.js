const grupoController = require('../control/grupoController');

module.exports = (app, banco) => {
  app.post('/api/grupos', (req, res) => grupoController.criar(banco, req, res));
  app.get('/api/grupos-resumo', (req, res) => grupoController.resumo(banco, req, res));
  app.put('/api/grupos/:id/status', (req, res) => grupoController.atualizarStatus(banco, req, res));
  app.get('/api/grupos-professor', (req, res) => grupoController.listarPorProfessor(banco, req, res));
};
