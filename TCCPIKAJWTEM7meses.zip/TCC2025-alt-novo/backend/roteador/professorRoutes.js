const professorController = require('../control/professorController');
const grupoController = require('../control/grupoController');

module.exports = (app, banco) => {
  app.get('/cadastro-professor', (_, res) =>
    res.sendFile(__dirname + "/../../frontend/cadastroProfessor.html")
  );
  app.post('/cadastro-professor', (req, res) =>
    professorController.cadastro(banco, req, res)
  );
  app.get('/api/professores', (req, res) =>
    professorController.listar(banco, req, res)
  );
  app.get('/api/professor/:id', (req, res) =>
    grupoController.listarPorProfessor(banco, req, res)
  );
};
