// backend/roteador/temaRoutes.js
const express = require('express');
const router = express.Router();
const TemaController = require('../control/temaController');

router.get('/', TemaController.buscar);

module.exports = router;
