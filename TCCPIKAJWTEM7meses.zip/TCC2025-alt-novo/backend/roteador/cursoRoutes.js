// backend/roteador/cursoRoutes.js
const express = require('express');
const router = express.Router();
const CursoController = require('../control/cursoController');

router.get('/', CursoController.listar);

module.exports = router;
