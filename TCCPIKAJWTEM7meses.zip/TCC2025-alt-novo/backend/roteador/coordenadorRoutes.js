const coordenadorController = require('../control/coordenadorController');

module.exports = (app, banco) => {
  app.get('/cadastro-coordenador', (_, res) => res.sendFile(__dirname + "/../../frontend/cadastroCoordenador.html"));
  app.post('/cadastro-coordenador', (req, res) => coordenadorController.cadastro(banco, req, res));
};
