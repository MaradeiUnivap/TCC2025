const entregaController = require('../control/entregaController');

module.exports = (app, banco, upload) => {
  app.post('/enviar-arquivo', upload.single('arquivoEnviado'), (req, res) => entregaController.enviarArquivo(banco, req, res));
  app.get('/api/entregas', (req, res) => entregaController.listar(banco, req, res));
  app.get('/download/:id', (req, res) => entregaController.download(banco, req, res));
};
