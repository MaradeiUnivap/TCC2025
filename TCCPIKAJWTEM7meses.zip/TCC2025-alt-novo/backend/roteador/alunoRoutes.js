const alunoController = require('../control/alunoController');

module.exports = (app, banco) => {
  app.get('/cadastro-aluno', (_, res) => res.sendFile(__dirname + "../../frontend/cadastroAluno.html"));
  app.post('/cadastro-aluno', (req, res) => alunoController.cadastro(banco, req, res));
  app.get('/api/alunos/search', (req, res) => alunoController.buscarPorNome(banco, req, res));
};