const path = require('path');

module.exports = (app, banco) => {
  app.get('/login', (_, res) =>
    res.sendFile(path.join(__dirname, '../../frontend/login.html'))
  );

  app.post('/login', (req, res) =>
    require('../control/authController').login(banco, req, res)
  );
};