const atividadeController = require('../control/atividadeController');

module.exports = (app, banco) => {
  app.get('/api/atividades', (req, res) => atividadeController.listar(banco, req, res));
  app.get('/api/atividade/:id', (req, res) => atividadeController.buscar(banco, req, res));
  app.post('/api/atividades', (req, res) => atividadeController.criar(banco, req, res));
  app.put('/api/atividade/:id', (req, res) => atividadeController.atualizar(banco, req, res));
  app.delete('/api/atividade/:id', (req, res) => atividadeController.deletar(banco, req, res));
};
