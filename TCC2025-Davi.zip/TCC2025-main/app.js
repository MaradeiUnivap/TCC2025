const express = require('express');
const multer = require('multer');
const mysql = require('mysql');
const path = require('path');

const ProfessorRouter = require('./backend/roteador/ProfessorRouter');
const AlunoRouter = require('./backend/roteador/AlunoRouter');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend'))); 
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const porta = 3000; 
const host = `http://localhost:${porta}`;

const banco = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        const nomeUnico = Date.now() + '-' + file.originalname;
        cb(null, nomeUnico);
    }
});

const upload = multer({ storage: storage });

const rotasProfessor = new ProfessorRouter(app, banco);
const rotasAlunos = new AlunoRouter(app, banco)

rotasProfessor.createRoutes(); 
rotasAlunos.createRoutes();


app.get('/login', function(req, res){
    res.sendFile(__dirname + "/frontend/login.html");  
});

app.post('/login', function(req, res) {
    const email = req.body.email;
    const senha = req.body.senha;

    if (!email || !senha) {
        return res.status(400).send('Email e senha são obrigatórios!');
    }

    banco.query(
        'SELECT * FROM aluno WHERE emailAluno = ? AND senhaAluno = ?',
        [email, senha],
        (erro, resultados) => {
            if (erro) {
                console.error('Erro na consulta de alunos:', erro);
                return res.status(500).send('Erro interno no servidor');
            }
            if (resultados.length > 0) {
                return res.redirect('/alunos');
            } else {
                banco.query(
                    'SELECT * FROM professor WHERE emailProfessor = ? AND senhaProfessor = ?',
                    [email, senha],
                    (erro2, resultados2) => {
                        if (erro2) {
                            console.error('Erro na consulta de professores:', erro2);
                            return res.status(500).send('Erro interno no servidor');
                        }

                        if (resultados2.length > 0) {
                            return res.redirect('/professores');
                        } else {
                            return res.status(401).send('Credenciais inválidas');
                        }
                    }
                );
            }
        }
    );
});


app.get('/api/professores', (req, res) => {
    banco.query('SELECT idProfessor, nomeProfessor FROM professor ORDER BY nomeProfessor', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar professores:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/cursos', (req, res) => {
    banco.query('SELECT idCurso, nomeCurso FROM curso ORDER BY nomeCurso', (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar cursos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

app.get('/api/alunos/search', (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.json([]);
    }

    // Este SQL seleciona apenas alunos que não existem na tabela aluno_grupo
    const sql = `
        SELECT a.idAluno, a.nomeAluno 
        FROM aluno a
        LEFT JOIN aluno_grupo ag ON a.idAluno = ag.idAluno
        WHERE ag.idAluno IS NULL AND a.nomeAluno LIKE ?
        LIMIT 10
    `;
    
    banco.query(sql, [`%${nome}%`], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar alunos:', erro);
            return res.status(500).json({ message: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});

// ROTA para exibir página de cadastro de alunos
app.get('/cadastro-aluno', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroAluno.html");
});

// ROTA para cadastrar aluno no banco
app.post('/cadastro-aluno', (req, res) => {
    const { nomeAluno, emailAluno, senhaAluno, idCurso } = req.body;

    if (!nomeAluno || !emailAluno || !senhaAluno || !idCurso) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno, idCurso) VALUES (?, ?, ?, ?)';
    banco.query(sql, [nomeAluno, emailAluno, senhaAluno, idCurso], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar aluno:", erro);
            return res.status(500).send("Erro ao cadastrar aluno.");
        }
        res.redirect('/login'); // Depois de cadastrar, manda pro login
    });
});


// ROTA para exibir página de cadastro de professores
app.get('/cadastro-professor', (req, res) => {
    res.sendFile(__dirname + "/frontend/cadastroProfessor.html");
});

// ROTA para cadastrar professor no banco
app.post('/cadastro-professor', (req, res) => {
    const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;

    if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
        return res.status(400).send('Preencha todos os campos.');
    }

    const sql = 'INSERT INTO professor (nomeProfessor, emailProfessor, senhaProfessor) VALUES (?, ?, ?)';
    banco.query(sql, [nomeProfessor, emailProfessor, senhaProfessor], (erro, resultado) => {
        if (erro) {
            console.error("Erro ao cadastrar professor:", erro);
            return res.status(500).send("Erro ao cadastrar professor.");
        }
        res.redirect('/login');
    });
});


// ROTA para criar um novo grupo e associar os membros
app.post('/api/grupos', (req, res) => {
    const { tema, idProfessor, idAlunos } = req.body;

    if (!tema || !idProfessor || !idAlunos || idAlunos.length === 0) {
        return res.status(400).json({ message: 'Dados incompletos para criar o grupo.' });
    }

    // Usaremos uma transação para garantir que ambas as operações (criar grupo e adicionar membros)
    // sejam concluídas com sucesso. Se uma falhar, a outra é desfeita.
    banco.getConnection((err, connection) => {
        if (err) {
            console.error('Erro ao obter conexão do banco:', err);
            return res.status(500).json({ message: 'Erro interno no servidor.' });
        }

        connection.beginTransaction(err => {
            if (err) {
                connection.release();
                return res.status(500).json({ message: 'Erro ao iniciar a transação.' });
            }

            // 1. Inserir o novo grupo na tabela 'grupotcc'
            // Assumindo que o curso é fixo (ID 1) por enquanto. Você pode adaptar para pegar o curso do aluno logado.
            const sqlGrupo = 'INSERT INTO grupotcc (tema, idCurso, idProfessor) VALUES (?, ?, ?)';
            connection.query(sqlGrupo, [tema, 1, idProfessor], (erro, resultadoGrupo) => {
                if (erro) {
                    return connection.rollback(() => {
                        connection.release();
                        console.error('Erro ao inserir grupo:', erro);
                        res.status(500).json({ message: 'Falha ao criar o grupo.' });
                    });
                }

                const idNovoGrupo = resultadoGrupo.insertId;

                // 2. Preparar os dados para inserir na tabela 'aluno_grupo'
                const valoresAlunoGrupo = idAlunos.map(idAluno => [idNovoGrupo, idAluno]);
                const sqlAlunoGrupo = 'INSERT INTO aluno_grupo (idGrupo, idAluno) VALUES ?';

                connection.query(sqlAlunoGrupo, [valoresAlunoGrupo], (erro, resultadoAlunos) => {
                    if (erro) {
                        return connection.rollback(() => {
                            connection.release();
                            console.error('Erro ao associar alunos ao grupo:', erro);
                            res.status(500).json({ message: 'Falha ao adicionar membros ao grupo.' });
                        });
                    }

                    // Se tudo deu certo, comita a transação
                    connection.commit(err => {
                        if (err) {
                            return connection.rollback(() => {
                                connection.release();
                                res.status(500).json({ message: 'Falha ao confirmar a criação do grupo.' });
                            });
                        }
                        
                        connection.release();
                        res.status(201).json({ message: 'Grupo criado com sucesso!' });
                    });
                });
            });
        });
    });
});


app.use('/professores', function(req, res) {
    res.sendFile(__dirname + "/frontend/professores.html")
});


app.use('/alunos', function(req, res) {
   res.sendFile(__dirname + "/frontend/alunos.html")
});

app.use('/cadastrargrupo', function(req, res) {
   res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
});

app.use('/cadastrargrupo', function(req, res) {
   res.sendFile(__dirname + "/frontend/cadastrargrupo.html")
});
app.use('/entrega', function(req, res) {
   res.sendFile(__dirname + "/frontend/entrega.html")
});

app.post('/enviar-arquivo', upload.single('arquivoEnviado'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('Nenhum arquivo foi enviado.');
    }

    const nomeOriginal = req.file.originalname;
    const nomeServidor = req.file.filename;
    const caminhoArquivo = path.join('uploads', nomeServidor); // <-- aqui foi ajustado

    const alunoId = 1; // Trocar depois por req.session.alunoId quando usar sessão

    const sql = 'INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, idAluno) VALUES (?, ?, ?, ?)';

    banco.query(sql, [nomeOriginal, nomeServidor, caminhoArquivo, alunoId], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao salvar no banco:', erro);
            return res.status(500).send('Erro ao salvar as informações do arquivo.');
        }
        console.log('Arquivo salvo no banco de dados!');
        res.send('Arquivo enviado com sucesso!');
    });
});


app.get('/api/entregas', (req, res) => {
    const sql = `
        SELECT e.idEntrega, e.nome_original, e.data_envio, a.nomeAluno 
        FROM entregas e
        JOIN aluno a ON e.idAluno = a.idAluno 
        ORDER BY e.data_envio DESC
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) {
            console.error('Erro ao buscar entregas:', erro);
            return res.status(500).json({ erro: 'Erro interno no servidor' });
        }
        res.json(resultados);
    });
});


app.get('/download/:id', (req, res) => {
    const entregaId = req.params.id;
    const sql = 'SELECT caminho_arquivo, nome_original FROM entregas WHERE idEntrega = ?';

    banco.query(sql, [entregaId], (erro, resultados) => {
        if (erro || resultados.length === 0) {
            return res.status(404).send('Arquivo não encontrado.');
        }

        const caminho = resultados[0].caminho_arquivo;
        const nomeOriginal = resultados[0].nome_original;

        res.download(caminho, nomeOriginal, (errDownload) => {
            if (errDownload) {
                console.error("Erro no download:", errDownload);
            }
        });
    });
});


app.use('/', function(req, res){
    res.sendFile(__dirname + "/frontend/inicial.html");  
});

app.listen(porta, () => {
    console.log(`Servidor rodando na porta ${porta}`);
    console.log(`Acesse em: ${host}`);
});